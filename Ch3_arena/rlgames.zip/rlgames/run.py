#!/usr/bin/env python3
"""
    Kevin Hon Yin Hau (All done by Claude) - Oct 2026
    https://kevinhyhau.co.uk/Ch3_arena/


    Reinforcement learning for board games, one program for every game.
    python run.py list
    python run.py selftest
    python run.py train tictactoe                 # a few minutes
    python run.py train connect4 --minutes 30
    python run.py experiments tictactoe           # the strategy-book experiments, see README
    python run.py lab morris --quick              # GAME LAB: measures a game and writes a report
    python run.py lab morris --variants "pieces=6,9 flying=on,off"
    python run.py replay morris 100               # watch game number 100 (from training or the lab) move by move
    python run.py export morris --sample 8        # save games in a file for the Game Arena web page (16 boards at once)
    python run.py eval connect4 results/connect4/model.npz [--tta]
    python run.py play tictactoe results/tictactoe/model.npz
    python run.py best_of tictactoe               # trains 5 variants, keeps the best, merges all five into one model
    python run.py learn tictactoe --model results/tictactoe/model.npz --games results/tictactoe/games.jsonl   # learn from games, then self-play; writes updated model and games
    Needs only Python 3.9+ and NumPy.

    """
import argparse, os, sys
if '--workers' in sys.argv or 'train' in sys.argv or 'experiments' in sys.argv or 'best_of' in sys.argv:
    for _v in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):      # one maths thread per process: parallel games, not parallel maths inside a tiny network
        os.environ.setdefault(_v, '1')
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rlg.games import GAMES, make_game, all_game_names
from rlg import train as T, baselines as B
from rlg.net import Net


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    sp.add_parser('list'); sp.add_parser('selftest')
    p = sp.add_parser('replay', help='watch a recorded game move by move'); p.add_argument('game'); p.add_argument('number', nargs='?', type=int, help='game number (see --list)')
    p.add_argument('--list', action='store_true', help='list the recorded games'); p.add_argument('--all', action='store_true', help='print the whole game at once, no waiting'); p.add_argument('--source', default=None, help='train or lab (default: whichever exists)'); p.add_argument('--out', default='results'); p.add_argument('--file', default=None, help='a games .jsonl file')
    p.add_argument('--limit', type=int, default=None, help='with --list: show only the first N')
    p = sp.add_parser('export', help='save recorded games in one file for the Game Arena web page'); p.add_argument('game'); p.add_argument('--numbers', default=None, help='e.g. 100,105-110'); p.add_argument('--sample', type=int, default=None, help='N random games')
    p.add_argument('--label', default=None, help='only games whose label contains this text'); p.add_argument('--source', default=None, help='train or lab'); p.add_argument('--out', default='results'); p.add_argument('--file', default=None, help='a games .jsonl file'); p.add_argument('--output', default=None, help='name of the file to write'); p.add_argument('--seed', type=int, default=0)
    p = sp.add_parser('learn', help='teach a model from games: your games file, games you played, and some self-play (the same code the Game Arena web page runs)')
    p.add_argument('game'); p.add_argument('--model', required=True); p.add_argument('--games', default=None, help='a games .jsonl file'); p.add_argument('--rounds', type=int, default=3); p.add_argument('--selfplay', type=int, default=6, help='self-play games per round')
    p.add_argument('--eval-games', type=int, default=8); p.add_argument('--out', default='results/learned'); p.add_argument('--seed', type=int, default=0)
    for c in ('train', 'experiments', 'best_of', 'eval', 'play', 'lab'):
        p = sp.add_parser(c); p.add_argument('game', help='one of: ' + ', '.join(all_game_names()))
        if c in ('eval', 'play'):
            p.add_argument('model'); p.add_argument('--tta', action='store_true', help='average the network over every rotated/mirrored view of the position (slower, steadier)')
        if c == 'lab':
            p.add_argument('--quick', action='store_true', help='fewer games: a first look in a few minutes'); p.add_argument('--seed', type=int, default=0); p.add_argument('--out', default='results'); p.add_argument('--variants', default=None, help='e.g. "pieces=6,9 flying=on,off" (Morris)')
        if c == 'train':
            p.add_argument('--keep-every', type=int, default=1, help='save only every Nth game (a long run saves a lot; 1 = all)')
        if c in ('train', 'experiments', 'best_of'):
            p.add_argument('--minutes', type=float, default=None, help='stop after this many minutes (otherwise the default number of iterations)')
            p.add_argument('--workers', type=int, default=None, help='CPU cores for self-play games (default: automatic = half your logical CPUs, max 8; 1 = off)')
            p.add_argument('--iters', type=int, default=None); p.add_argument('--seed', type=int, default=0); p.add_argument('--out', default='results')
        if c == 'best_of':
            p.add_argument('--eval-games', type=int, default=None); p.add_argument('--positions', type=int, default=3000, help='positions the committee labels for the student'); p.add_argument('--sims', type=int, default=40, help='search per position for the committee')
        if c == 'experiments':
            p.add_argument('--which', default='all', help='comma list: baseline,no_noise,no_temperature,few_sims,no_augment')
    a = ap.parse_args()
    if a.cmd in ('train', 'experiments', 'best_of'):
        T.DEFAULT_WORKERS = a.workers if a.workers else T.auto_workers(); print('self-play on %d CPU core(s)  (change with --workers N)' % T.DEFAULT_WORKERS)
    if a.cmd == 'list':
        for g in all_game_names():
            G = make_game(g); print('%-13s actions %-5d inputs %-4d  %s' % (g, G.n_actions, G.input_size(), ('default %d iterations' % T.CONFIGS[g]['iters']) if g in T.CONFIGS else 'your game (lab works; for train add a CONFIGS entry in rlg/train.py)'))
    elif a.cmd == 'selftest':
        from rlg import selftest; selftest.run()
    elif a.cmd == 'train':
        folder, _ = T.train(a.game, a.minutes, a.iters, a.seed, a.out, keep_every=a.keep_every); print('\nDone. The report is in', os.path.join(folder, 'report.md'))
    elif a.cmd == 'experiments':
        from rlg import experiments; experiments.run(a.game, a.minutes, a.iters, a.seed, a.out, a.which)
    elif a.cmd == 'best_of':
        from rlg import bestof; bestof.run(a.game, a.minutes, a.iters, a.seed, a.out, a.eval_games, a.positions, a.sims)
    elif a.cmd == 'lab':
        from rlg import lab; lab.run(a.game, a.quick, a.seed, a.out, a.variants)
    elif a.cmd == 'replay':
        from rlg import gamelog
        cands = {'train': os.path.join(a.out, a.game, 'games.jsonl'), 'lab': os.path.join(a.out, 'lab_%s_games.jsonl' % a.game)}
        path = a.file or (cands[a.source] if a.source else next((p for p in cands.values() if os.path.exists(p)), cands['train']))
        if not os.path.exists(path):
            raise SystemExit('No recorded games at %s. Run `python run.py train %s` or `python run.py lab %s` first (or pass --file).' % (path, a.game, a.game))
        if a.list or a.number is None:
            gamelog.list_games(path, a.limit)
            if a.number is None and not a.list:
                print('\nPick one:  python run.py replay %s <number>' % a.game)
        else:
            gamelog.replay(make_game(a.game), path, a.number, step=not a.all)
    elif a.cmd == 'export':
        from rlg import arena
        cands = {'train': os.path.join(a.out, a.game, 'games.jsonl'), 'lab': os.path.join(a.out, 'lab_%s_games.jsonl' % a.game)}
        path = a.file or (cands[a.source] if a.source else next((p for p in cands.values() if os.path.exists(p)), cands['train']))
        if not os.path.exists(path):
            raise SystemExit('No recorded games at %s. Run `python run.py train %s` or `python run.py lab %s` first.' % (path, a.game, a.game))
        arena.export(a.game, path, arena.parse_numbers(a.numbers) if a.numbers else None, a.sample or (None if a.numbers or a.label else 16), a.label, a.output, a.seed)
    elif a.cmd == 'learn':
        import json as _j
        from rlg import web_api as W
        r = _j.loads(W.set_model(a.model, a.game)); print(r)
        if not r['ok']:
            raise SystemExit(r['error'])
        if a.games:
            r = _j.loads(W.set_games(open(a.games).read())); print(r)
            if not r['ok']:
                raise SystemExit(r['error'])
        r = _j.loads(W.learn_begin(_j.dumps(dict(rounds=a.rounds, selfplay=a.selfplay, eval_games=a.eval_games, seed=a.seed))))
        if not r['ok']:
            raise SystemExit(r['error'])
        while True:
            d = _j.loads(W.learn_step())
            if d.get('error'):
                raise SystemExit(d['error'])
            if d['done']:
                break
            print('%3d%%  %s' % (d['pct'], d['msg']), flush=True)
        os.makedirs(a.out, exist_ok=True)
        open(os.path.join(a.out, 'model_updated.npz'), 'wb').write(__import__('base64').b64decode(W.export_model_b64(True))); open(os.path.join(a.out, 'games_updated.jsonl'), 'w').write(W.export_games_text()); open(os.path.join(a.out, 'report.md'), 'w').write(W.export_report())
        print(W.export_report()); print('Wrote model_updated.npz, games_updated.jsonl and report.md to', a.out)
    elif a.cmd == 'eval':
        g = make_game(a.game); net = Net.load(a.model); cfg = T.CONFIGS[a.game]; rng = np.random.default_rng(1)
        print(T.evaluate(g, net, None, dict(cfg, eval_games=40), rng, a.game, tta=a.tta))
    elif a.cmd == 'play':
        play(a.game, a.model, a.tta)


def play(name, model, tta=False):
    g = make_game(name); net = Net.load(model); ai = B.net_mcts_agent(net, T.CONFIGS[name]['eval_sims'] * 2, tta); rng = np.random.default_rng()
    s = g.initial(); me = 1 if input('Go first? [y/n] ').strip().lower() != 'n' else -1
    while g.result(s) is None:
        print('\n' + g.render(s)); L = list(g.legal(s))
        if s.turn == me:
            while True:
                try:
                    x = int(input('your move %s: ' % L))
                    if x in L:
                        break
                except ValueError:
                    pass
            s = g.step(s, x)
        else:
            m = ai(g, s, rng); print('computer plays', m); s = g.step(s, m)
    print('\n' + g.render(s)); print('You win!' if s.winner == me else 'Draw.' if s.winner == 0 else 'The computer wins.')


if __name__ == '__main__':
    main()
