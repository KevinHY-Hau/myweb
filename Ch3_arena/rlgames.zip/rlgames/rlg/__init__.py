"""rlg: a small, readable AlphaZero-style learner that works on any game that follows rlg.games.Game.

    Kevin Hon Yin Hau (All done by Claude) - Oct 2026 https://kevinhyhau.co.uk/Ch3_arena/
"""
