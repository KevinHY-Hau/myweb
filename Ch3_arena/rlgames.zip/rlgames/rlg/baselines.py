"""Fixed opponents. A learner only means something if you measure it against things that do NOT change.
random < greedy < rollout-MCTS (< perfect, for tic-tac-toe only). All agents are functions  agent(game, state, rng) -> action."""
import numpy as np
from . import gamelog
from .mcts import search, pick


def random_agent(game, s, rng):
    L = game.legal(s); return int(L[rng.integers(len(L))])


def greedy_agent(game, s, rng):
    """1-ply: take a winning move if there is one; else avoid moves that let the opponent win at once; else random."""
    wins, safe = [], []
    for a in game.legal(s):
        t = game.step(s, a)
        if t.winner is not None:
            if t.winner == s.turn:
                wins.append(a)
            elif t.winner == 0:
                safe.append(a)
            continue
        if not any(game.step(t, b).winner == t.turn for b in game.legal(t)):
            safe.append(a)
    pool = wins or safe or list(game.legal(s)); return int(pool[rng.integers(len(pool))])


def _material(game, t):
    """piece balance for the player to move at t, from the game's own features (my_total / my_pieces). 0 when the game has no pieces to count."""
    f = game.features(t)
    for a, b in (('my_total', 'opp_total'), ('my_pieces', 'opp_pieces')):
        if a in f:
            return f[a] - f[b]
    return 0.0


def rollout_evaluator(game, s, rng_holder, cap=None):
    """value = outcome of one random play-out. With cap, a play-out that has not ended after `cap` moves is scored by who has more pieces."""
    rng = rng_holder[0]; me = s.turn; t = s; k = 0
    while game.result(t) is None:
        if cap is not None and k >= cap:
            d = _material(game, t) * (1 if t.turn == me else -1); return float(np.tanh(d / 2.0))
        L = game.legal(t); t = game.step(t, int(L[rng.integers(len(L))])); k += 1
    return 0.0 if t.winner == 0 else (1.0 if t.winner == me else -1.0)


def rollout_mcts_agent(sims, cap=None):
    holder = [None]

    def ev(game, s):
        n = len(game.legal(s)); return np.full(n, 1.0 / n), rollout_evaluator(game, s, holder, cap)

    def agent(game, s, rng):
        holder[0] = rng; legal, visits = search(game, s, ev, sims, rng, c_puct=1.4); return pick(legal, visits, 0, rng)
    return agent


def perfect_ttt_agent():
    """exact minimax for tic-tac-toe (cached). Plays randomly among the best moves, so it never loses and punishes every mistake."""
    cache = {}

    def val(game, s):
        k = game.key(s)
        if k in cache:
            return cache[k]
        r = game.result(s)
        if r is None:
            r = max(-val(game, game.step(s, a)) for a in game.legal(s))
        cache[k] = r; return r

    def agent(game, s, rng):
        L = game.legal(s); sc = [-val(game, game.step(s, a)) for a in L]; best = [a for a, v in zip(L, sc) if v == max(sc)]
        return int(best[rng.integers(len(best))])
    return agent


def net_policy_agent(net):
    """no search at all: play the network's single favourite legal move ('instinct')"""
    def agent(game, s, rng):
        L = game.legal(s); logits, _ = net.predict(game.encode(s)); return int(L[int(np.argmax(logits[L]))])
    return agent


def net_mcts_agent(net, sims, tta=False):
    from .mcts import net_evaluator
    ev = net_evaluator(net, tta)

    def agent(game, s, rng):
        legal, visits = search(game, s, ev, sims, rng, noise=0.0); return pick(legal, visits, 0, rng)
    return agent


def play_one(game, agent_a, agent_b, g, rng):
    """one game. A plays first when g is even. returns (final state, moves, a_first)"""
    s = game.initial(); a_first = (g % 2 == 0); acts = []
    while game.result(s) is None:
        a_turn = (s.turn == 1) == a_first
        a = (agent_a if a_turn else agent_b)(game, s, rng); acts.append(a); s = game.step(s, a)
    return s, acts, a_first


def tally(results, names=None):
    """results = list of (final state or (winner, why), moves, a_first). returns the same dict as play_match; also saves the games to the recorder"""
    w = d = l = 0; why = {}
    for s, acts, a_first in results:
        winner, wy = (s.winner, s.why)
        a_color = 1 if a_first else -1
        gamelog.record(acts, s, players=(list(names) if a_first else [names[1], names[0]]) if names else None)
        if winner == 0:
            d += 1
        elif winner == a_color:
            w += 1; why[wy] = why.get(wy, 0) + 1
        else:
            l += 1
    n = max(1, len(results))
    return dict(win=w, draw=d, loss=l, score=(w + 0.5 * d) / n, why=why)


def play_match(game, agent_a, agent_b, games, rng, names=None):
    """A plays first in half the games. returns {'win','draw','loss', 'score', 'why'} from A's point of view.
    Every game is also saved by the game recorder (rlg/gamelog.py) when it is switched on. names = (name of A, name of B) for the log."""
    return tally([play_one(game, agent_a, agent_b, g, rng) for g in range(games)], names)
