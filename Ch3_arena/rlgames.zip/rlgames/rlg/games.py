"""Four games behind ONE interface. To teach the learner a new game, write a class like these (about 60 lines).

A state is a State object. Colours are absolute: 1 = the player who moves first, -1 = the second player.
Every game must give:  initial()  legal(s)  step(s, a)  result(s)  encode(s)  render(s)  and the numbers n_actions, planes, H, W.
step() never changes the state you pass in (it returns a new one), so search can branch freely.
result(s) is None while the game goes on, otherwise +1 / 0 / -1 for the player TO MOVE in s (the usual AlphaZero convention).
"""
import numpy as np


class State:
    __slots__ = ('b', 'turn', 'ply', 'winner', 'extra', 'why', '_legal')

    def __init__(self, b, turn=1, ply=0, winner=None, extra=None, why=''):
        self.b, self.turn, self.ply, self.winner, self.extra, self.why, self._legal = b, turn, ply, winner, extra, why, None

    def copy(self):
        return State(self.b.copy(), self.turn, self.ply, self.winner, self.extra, self.why)


class Game:
    name = 'game'
    H = W = 0          # shape of the encoded planes
    planes = 2         # number of planes in encode()
    n_actions = 0

    def input_size(self):
        return self.planes * self.H * self.W

    def result(self, s):
        if s.winner is None:
            return None
        return 0.0 if s.winner == 0 else (1.0 if s.winner == s.turn else -1.0)

    def key(self, s):
        return s.b.tobytes() + bytes([s.turn % 256]) + repr(s.extra).encode()

    # ---- symmetry. A game that looks the same after a rotation or mirror lists the transformations in self.syms.
    # Each one is a pair of index arrays (xperm, pperm):  transformed_input = x[xperm]   transformed_policy = pi[pperm]
    # (entry j of the transformed thing came from entry perm[j] of the original). Training then sees every position in all its views,
    # so what is learnt in one corner is known in all four, and play can average the views (see net_evaluator(tta=True)).
    syms = None
    family = 'unknown'
    feature_notes = {}

    def augment(self, x, pi):
        """all (input, policy) views of one position. The first is always the original."""
        if not self.syms:
            return [(x, pi)]
        return [(x[xp], pi[pp]) for xp, pp in self.syms]

    def transform(self, s, k):
        """the same position seen through symmetry k (used by the self-test and to prove the rules really are symmetric)"""
        perm = self.sq_perms[k]; t = s.copy(); t.b = s.b.ravel()[perm].reshape(s.b.shape).copy(); t._legal = None
        return t

    def features(self, s):
        """named numbers describing a position for the player to move. Default works for any square-board game; a game can override it with its own."""
        b, me = s.b, s.turn; f = {'my_pieces': int((b == me).sum()), 'opp_pieces': int((b == -me).sum()), 'my_moves': len(self.legal(s))}
        f['piece_balance'] = f['my_pieces'] - f['opp_pieces']
        if self.H > 1:
            g = b.reshape(self.H, self.W); c = (self.H - 1) / 2, (self.W - 1) / 2; yy, xx = np.indices(g.shape)
            centre = (np.abs(yy - c[0]) <= self.H / 4) & (np.abs(xx - c[1]) <= self.W / 4)
            f['my_centre'] = int(((g == me) & centre).sum()); f['opp_centre'] = int(((g == -me) & centre).sum())
            for who, col in (('my', me), ('opp', -me)):
                m = g == col; f[who + '_links'] = int((m[:, 1:] & m[:, :-1]).sum() + (m[1:, :] & m[:-1, :]).sum())
        return f

    def encode(self, s):
        me = (s.b == s.turn).astype(np.float32)
        you = (s.b == -s.turn).astype(np.float32)
        return np.concatenate([me.ravel(), you.ravel()])

    def render(self, s):
        sym = {0: '.', 1: 'X', -1: 'O'}
        return '\n'.join(' '.join(sym[int(v)] for v in row) for row in s.b.reshape(self.H, self.W))


def square_perms(n, full=True):
    """the 8 ways to turn or flip an n x n board (4 rotations, each with and without a mirror). entry j = which original square lands on square j.
    full=False keeps only 'as it is' and 'left-right mirror' (for games with gravity, like Connect 4, where up is not the same as sideways)."""
    idx = np.arange(n * n).reshape(n, n); out = []
    for k in range(4):
        for f in (False, True):
            a = np.rot90(idx, k)
            out.append((a[:, ::-1] if f else a).ravel().copy())
    return out if full else [out[0], out[1]]


def _xperm(perm, planes):
    n2 = len(perm); return np.concatenate([perm + p * n2 for p in range(planes)])


# ---------------------------------------------------------------- tic-tac-toe
class TicTacToe(Game):
    family = 'connect'
    name = 'tictactoe'
    H = W = 3
    n_actions = 9
    LINES = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6)]

    def initial(self):
        return State(np.zeros(9, np.int8))

    def legal(self, s):
        return np.flatnonzero(s.b == 0) if s.winner is None else np.array([], int)

    def step(self, s, a):
        t = s.copy(); t.b[a] = s.turn; t.ply += 1
        if any(t.b[i] == t.b[j] == t.b[k] == s.turn for i, j, k in self.LINES):
            t.winner = s.turn; t.why = 'line'
        elif t.ply == 9:
            t.winner = 0; t.why = 'full'
        t.turn = -s.turn
        return t

    def __init__(self):
        self.sq_perms = square_perms(3); self.syms = [(_xperm(p, self.planes), p) for p in self.sq_perms]


# ---------------------------------------------------------------- connect 4
class Connect4(Game):
    """rows x cols board, connect k to win. Row 0 is the TOP. An action is the column you drop into."""
    family = 'connect'
    planes = 2

    def __init__(self, rows=6, cols=7, k=4):
        self.rows, self.cols, self.k = rows, cols, k
        self.H, self.W, self.n_actions = rows, cols, cols
        self.name = 'connect4' if (rows, cols, k) == (6, 7, 4) else 'connect4mini'
        self._init_syms()

    def initial(self):
        return State(np.zeros((self.rows, self.cols), np.int8))

    def legal(self, s):
        return np.flatnonzero(s.b[0] == 0) if s.winner is None else np.array([], int)

    def _wins(self, b, r, c, me):
        for dr, dc in ((0, 1), (1, 0), (1, 1), (1, -1)):
            n = 1
            for sg in (1, -1):
                rr, cc = r + dr * sg, c + dc * sg
                while 0 <= rr < self.rows and 0 <= cc < self.cols and b[rr, cc] == me:
                    n += 1; rr += dr * sg; cc += dc * sg
            if n >= self.k:
                return True
        return False

    def step(self, s, a):
        t = s.copy(); col = t.b[:, a]; r = int(np.flatnonzero(col == 0).max()); t.b[r, a] = s.turn; t.ply += 1
        if self._wins(t.b, r, a, s.turn):
            t.winner = s.turn; t.why = 'line'
        elif t.ply == self.rows * self.cols:
            t.winner = 0; t.why = 'full'
        t.turn = -s.turn
        return t

    def _init_syms(self):
        idx = np.arange(self.rows * self.cols).reshape(self.rows, self.cols)
        self.sq_perms = [idx.ravel().copy(), idx[:, ::-1].ravel().copy()]           # as it is, and left-right mirror (gravity forbids the others)
        cols = np.arange(self.cols)
        self.syms = [(_xperm(self.sq_perms[0], self.planes), cols), (_xperm(self.sq_perms[1], self.planes), cols[::-1].copy())]


# ---------------------------------------------------------------- othello
class Othello(Game):
    """n x n Othello (default 6). Action n*n means 'pass' and is only legal when you have no move."""
    family = 'surround'
    DIRS = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    def __init__(self, n=6):
        self.n = n; self.H = self.W = n; self.n_actions = n * n + 1; self.name = 'othello%d' % n
        self.sq_perms = square_perms(n); tail = np.array([n * n])           # the 'pass' action stays itself
        self.syms = [(_xperm(p, self.planes), np.concatenate([p, tail])) for p in self.sq_perms]

    def initial(self):
        n = self.n; b = np.zeros((n, n), np.int8); m = n // 2
        b[m - 1, m - 1] = b[m, m] = -1; b[m - 1, m] = b[m, m - 1] = 1
        return State(b, extra=False)       # extra = "the last move was a pass"

    def _flips(self, b, r, c, me):
        out = []
        for dr, dc in self.DIRS:
            rr, cc, run = r + dr, c + dc, []
            while 0 <= rr < self.n and 0 <= cc < self.n and b[rr, cc] == -me:
                run.append((rr, cc)); rr += dr; cc += dc
            if run and 0 <= rr < self.n and 0 <= cc < self.n and b[rr, cc] == me:
                out += run
        return out

    def _moves(self, b, me):
        return [r * self.n + c for r in range(self.n) for c in range(self.n) if b[r, c] == 0 and self._flips(b, r, c, me)]

    def legal(self, s):
        if s.winner is not None:
            return np.array([], int)
        if s._legal is None:
            m = self._moves(s.b, s.turn)
            s._legal = np.array(m if m else [self.n * self.n], int)
        return s._legal

    def step(self, s, a):
        t = s.copy(); n = self.n; t.ply += 1
        if a == n * n:                                    # pass
            if s.extra:                                   # two passes in a row: game over
                d = int(t.b.sum()) * s.turn
                t.winner = 0 if d == 0 else (s.turn if d > 0 else -s.turn)
                t.why = 'passes'
            t.extra = True
        else:
            r, c = divmod(int(a), n)
            for fr, fc in self._flips(t.b, r, c, s.turn):
                t.b[fr, fc] = s.turn
            t.b[r, c] = s.turn; t.extra = False
            if not (t.b == 0).any():
                d = int(t.b.sum()) * s.turn
                t.winner = 0 if d == 0 else (s.turn if d > 0 else -s.turn); t.why = 'full'
        t.turn = -s.turn
        return t

# ---------------------------------------------------------------- flock (my own game from chapter 59)
class Flock(Game):
    """A stone moves in a straight line over empty squares, as far as its flock is big (flock = touching stones of one colour, at most `cap`).
    After you move, enemy stones sandwiched between the moved stone and another of yours are captured. Capture enough stones, or leave the
    other side with no move, to win. No stepping straight back. After max_ply moves, more stones wins.
    An action is from_square * n*n + to_square."""
    family = 'capture + reach'
    planes = 4
    DIRS = [(0, -1), (0, 1), (-1, 0), (1, 0)]

    def __init__(self, n=5, stones=5, lose=2, cap=3, max_ply=100):
        self.n, self.stones, self.lose, self.cap, self.max_ply = n, stones, lose, cap, max_ply
        self.H = self.W = n; self.n_actions = (n * n) ** 2; self.name = 'flock%d' % n
        # the rules are the same after any turn or mirror (straight-line moves, sandwiches), so all 8 views are valid. An action is a pair
        # (from, to) of squares, so the policy permutation moves both squares.
        self.sq_perms = square_perms(n); N = n * n
        self.syms = [(_xperm(p, self.planes), (p[:, None] * N + p[None, :]).ravel()) for p in self.sq_perms]

    def initial(self):
        n = self.n; b = np.zeros((n, n), np.int8)

        def place(side, row0, dr):
            k, r = self.stones, 0
            while k > 0:
                cnt = min(k, n); off = (n - cnt) >> 1
                b[row0 + dr * r, off:off + cnt] = side; k -= cnt; r += 1
        place(-1, 0, 1); place(1, n - 1, -1)
        return State(b, extra=(None, None))              # extra = last move (from, to) of the first and the second player

    def flocks(self, b):
        n = self.n; size = np.zeros((n, n), np.int8); seen = np.zeros((n, n), bool)
        for r in range(n):
            for c in range(n):
                if b[r, c] == 0 or seen[r, c]:
                    continue
                side, stack, comp = b[r, c], [(r, c)], []
                seen[r, c] = True
                while stack:
                    y, x = stack.pop(); comp.append((y, x))
                    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                        yy, xx = y + dy, x + dx
                        if 0 <= yy < n and 0 <= xx < n and not seen[yy, xx] and b[yy, xx] == side:
                            seen[yy, xx] = True; stack.append((yy, xx))
                for y, x in comp:
                    size[y, x] = len(comp)
        return size

    def _moves(self, b, side, lo):
        n = self.n; fl = self.flocks(b); out = []
        for r in range(n):
            for c in range(n):
                if b[r, c] != side:
                    continue
                R = min(int(fl[r, c]), self.cap); i = r * n + c
                for dx, dy in self.DIRS:
                    for st in range(1, R + 1):
                        x, y = c + dx * st, r + dy * st
                        if not (0 <= x < n and 0 <= y < n) or b[y, x] != 0:
                            break
                        t = y * n + x
                        if lo is not None and lo == (t, i):          # moving straight back is not allowed
                            continue
                        out.append(i * n * n + t)
        return out

    def legal(self, s):
        if s.winner is not None:
            return np.array([], int)
        if s._legal is None:
            lo = s.extra[0 if s.turn == 1 else 1]
            s._legal = np.array(self._moves(s.b, s.turn, lo), int)
        return s._legal

    def step(self, s, a):
        n = self.n; f, t_ = divmod(int(a), n * n); t = s.copy(); side = s.turn
        fr, fc, tr, tc = f // n, f % n, t_ // n, t_ % n
        t.b[fr, fc] = 0; t.b[tr, tc] = side
        for dx, dy in self.DIRS:
            ay, ax, by, bx = tr + dy, tc + dx, tr + 2 * dy, tc + 2 * dx
            if 0 <= ay < n and 0 <= ax < n and 0 <= by < n and 0 <= bx < n and t.b[ay, ax] == -side and t.b[by, bx] == side:
                t.b[ay, ax] = 0
        lo = list(s.extra); lo[0 if side == 1 else 1] = (f, t_); t.extra = tuple(lo)
        t.ply += 1
        opp = int((t.b == -side).sum())
        if opp <= self.lose:
            t.winner = side; t.why = 'captured'
        elif t.ply >= self.max_ply:
            mine = int((t.b == side).sum()); t.winner = 0 if mine == opp else (side if mine > opp else -side); t.why = 'limit'
        else:
            t.turn = -side
            if not len(self.legal(t)):
                t.winner = side; t.why = 'blocked'
            t.turn = -side
            return t
        t.turn = -side
        return t

    def transform(self, s, k):
        t = Game.transform(self, s, k); inv = np.argsort(self.sq_perms[k])      # where each original square went
        t.extra = tuple(None if m is None else (int(inv[m[0]]), int(inv[m[1]])) for m in s.extra)
        return t

    def encode(self, s):
        n = self.n; fl = np.minimum(self.flocks(s.b), self.cap) / self.cap
        me = (s.b == s.turn); you = (s.b == -s.turn)
        return np.concatenate([me.ravel(), you.ravel(), (fl * me).ravel(), np.full(n * n, s.ply / self.max_ply)]).astype(np.float32)



# ---------------------------------------------------------------- nine men's morris (the first game given to the Game Lab)
class Morris(Game):
    """Nine Men's Morris on the 24-point board of three squares. Points 0-7 are the outer square, 8-15 the middle, 16-23 the inner, each counted
    clockwise from its top-left corner (corner, middle of side, corner, ...). Rules as I understand them (the Lab prints these back so you can check):
      1. PLACE: players take turns putting one of their `pieces` pieces on any empty point until all are placed.
      2. MOVE: then each turn slide one piece along a line to a neighbouring empty point.
      3. FLY: a player down to exactly 3 pieces may move any piece to any empty point (switch off with flying=False).
      4. MILL: making three of your pieces in a row along a line lets you remove one enemy piece, which must not be in a mill unless every enemy piece is.
      5. WIN: the enemy has fewer than 3 pieces (on the board plus still to place), or the enemy cannot move. Draw after `max_ply` actions.
    An action is: 0-23 place on that point, 24-599 move a*24+b (+24), 600-623 remove that point. A removal is its own action by the same player."""
    name = 'morris'; H = 1; W = 24; planes = 5; n_actions = 624; family = 'mill / placement'
    MILLS = [(0, 1, 2), (2, 3, 4), (4, 5, 6), (6, 7, 0), (8, 9, 10), (10, 11, 12), (12, 13, 14), (14, 15, 8), (16, 17, 18), (18, 19, 20), (20, 21, 22), (22, 23, 16),
             (1, 9, 17), (3, 11, 19), (5, 13, 21), (7, 15, 23)]
    ADJ = [[] for _ in range(24)]
    for r in range(3):
        for k in range(8):
            ADJ[r * 8 + k] += [r * 8 + (k + 1) % 8, r * 8 + (k - 1) % 8]
            if k % 2 == 1 and r < 2:
                ADJ[r * 8 + k].append((r + 1) * 8 + k); ADJ[(r + 1) * 8 + k].append(r * 8 + k)
    feature_notes = {'my_mills': 'mills you have closed', 'opp_mills': 'mills the opponent has closed', 'my_open_pairs': 'your two-in-a-row with the third point empty',
                     'opp_open_pairs': "opponent's two-in-a-row with the third point empty", 'my_blocked': 'your pieces with no empty neighbour', 'opp_blocked': "opponent's pieces with no empty neighbour",
                     'my_total': 'pieces you still have (board + hand)', 'opp_total': 'pieces the opponent still has (board + hand)', 'my_hand': 'pieces still to place (you)', 'opp_hand': 'pieces still to place (opponent)'}

    def __init__(self, pieces=9, flying=True, max_ply=200):
        self.pieces, self.flying, self.max_ply = pieces, flying, max_ply
        self.name = 'morris' if (pieces, flying, max_ply) == (9, True, 200) else 'morris(pieces=%d,flying=%s)' % (pieces, 'on' if flying else 'off')
        coords = []
        for r in range(3):
            d = 3 - r
            for dx, dy in ((-1, -1), (0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0)):
                coords.append((3 + dx * d, 3 + dy * d))
        where = {c: i for i, c in enumerate(coords)}; self.sq_perms = []
        for k in range(4):
            for f in (False, True):
                for swap in (False, True):
                    perm = np.zeros(24, int)
                    for j, (x, y) in enumerate(coords):          # transformed point j came from original point perm[j]
                        u, v = x - 3, y - 3
                        if swap:
                            d = max(abs(u), abs(v)); u, v = u * (4 - d) // d, v * (4 - d) // d
                        for _ in range(k):
                            u, v = -v, u
                        if f:
                            u = -u
                        perm[j] = where[(u + 3, v + 3)]
                    self.sq_perms.append(perm)
        self.syms = []
        for p in self.sq_perms:
            pp = np.concatenate([p, 24 + (p[:, None] * 24 + p[None, :]).ravel(), 600 + p]); self.syms.append((_xperm(p, self.planes), pp))

    def describe(self):
        return ['Board: 24 points on three nested squares; lines join the points of each square and the middles of the four sides.',
                'Each player has %d pieces. First everyone places pieces one at a time on empty points.' % self.pieces,
                'After all are placed, you slide one piece per turn to a neighbouring empty point.',
                ('A player with exactly 3 pieces left may "fly": move a piece to ANY empty point.' if self.flying else 'No flying: pieces always slide, even with 3 left.'),
                'Three of your pieces in a row on a line is a MILL: remove one enemy piece, one that is not in a mill (unless all of them are).',
                'You win when the enemy has fewer than 3 pieces (board plus hand) or cannot move. Draw after %d actions.' % self.max_ply]

    def initial(self):
        return State(np.zeros(24, np.int8), extra=(self.pieces, self.pieces, False))      # hand of the first player, hand of the second, "must remove now"

    def _mill_at(self, b, p, c):
        return any(p in m and b[m[0]] == b[m[1]] == b[m[2]] == c for m in self.MILLS)

    def _in_mill(self, b, p):
        return self._mill_at(b, p, b[p])

    def _moves(self, s):
        b, me = s.b, s.turn; hand = s.extra[0 if me == 1 else 1]
        if hand > 0:
            return [p for p in range(24) if b[p] == 0]
        mine = [p for p in range(24) if b[p] == me]; empties = [p for p in range(24) if b[p] == 0]
        if self.flying and len(mine) == 3:
            return [24 + a * 24 + e for a in mine for e in empties]
        return [24 + a * 24 + e for a in mine for e in self.ADJ[a] if b[e] == 0]

    def legal(self, s):
        if s.winner is not None:
            return np.array([], int)
        if s._legal is None:
            if s.extra[2]:                                                              # a mill was just closed: choose an enemy piece to remove
                foe = [p for p in range(24) if s.b[p] == -s.turn]; free = [p for p in foe if not self._in_mill(s.b, p)]
                s._legal = np.array([600 + p for p in (free or foe)], int)
            else:
                s._legal = np.array(self._moves(s), int)
        return s._legal

    def _count(self, t, colour):
        return int((t.b == colour).sum()) + t.extra[0 if colour == 1 else 1]

    def step(self, s, a):
        t = s.copy(); me = s.turn; a = int(a); h1, h2, pend = s.extra; t.ply += 1
        if a >= 600:                                                                    # removal
            t.b[a - 600] = 0; pend = False
            if self._count(t, -me) < 3:
                t.winner = me; t.why = 'reduced'
        else:
            if a < 24:
                t.b[a] = me; p = a
                if me == 1:
                    h1 -= 1
                else:
                    h2 -= 1
            else:
                f, p = divmod(a - 24, 24); t.b[f] = 0; t.b[p] = me
            pend = self._mill_at(t.b, p, me)
        t.extra = (h1, h2, pend)
        if t.winner is None:
            if pend:
                t._legal = None; t.turn = me                                            # same player moves again: must remove a piece
                return t
            if not pend:
                t.turn = -me
                if t.ply >= self.max_ply:
                    t.winner = 0; t.why = 'limit'
                elif not len(self.legal(t)):
                    t.winner = me; t.why = 'blocked'
                return t
        t.turn = -me
        return t

    def encode(self, s):
        me = (s.b == s.turn); you = (s.b == -s.turn); h = s.extra; mine, theirs = (h[0], h[1]) if s.turn == 1 else (h[1], h[0])
        one = np.ones(24, np.float32)
        return np.concatenate([me, you, one * float(s.extra[2]), one * mine / self.pieces, one * theirs / self.pieces]).astype(np.float32)

    def features(self, s):
        b, me = s.b, s.turn; h = s.extra; mine, theirs = (h[0], h[1]) if me == 1 else (h[1], h[0]); f = {}
        def mills(c): return sum(1 for m in self.MILLS if b[m[0]] == b[m[1]] == b[m[2]] == c)
        def pairs(c): return sum(1 for m in self.MILLS if sorted(int(b[i]) for i in m) == sorted([c, c, 0]))
        def blocked(c): return sum(1 for p in range(24) if b[p] == c and all(b[e] != 0 for e in self.ADJ[p]))
        f['my_total'] = int((b == me).sum()) + mine; f['opp_total'] = int((b == -me).sum()) + theirs
        f['my_mills'] = mills(me); f['opp_mills'] = mills(-me); f['my_open_pairs'] = pairs(me); f['opp_open_pairs'] = pairs(-me)
        f['my_blocked'] = blocked(me); f['opp_blocked'] = blocked(-me); f['my_hand'] = mine; f['opp_hand'] = theirs
        return f

    def render(self, s):
        c = {0: '.', 1: 'X', -1: 'O'}; b = [c[int(v)] for v in s.b]
        return '\n'.join([
            '%s-----------%s-----------%s' % (b[0], b[1], b[2]), '|           |           |',
            '|   %s-------%s-------%s   |' % (b[8], b[9], b[10]), '|   |       |       |   |', '|   |   %s---%s---%s   |   |' % (b[16], b[17], b[18]), '|   |   |       |   |   |',
            '%s---%s---%s       %s---%s---%s' % (b[7], b[15], b[23], b[19], b[11], b[3]), '|   |   |       |   |   |',
            '|   |   %s---%s---%s   |   |' % (b[22], b[21], b[20]), '|   |       |       |   |', '|   %s-------%s-------%s   |' % (b[14], b[13], b[12]), '|           |           |',
            '%s-----------%s-----------%s' % (b[6], b[5], b[4]),
            'to place: X %d, O %d   %s' % (s.extra[0], s.extra[1], 'REMOVE a piece' if s.extra[2] else '')])

def make_game(name, **kw):
    """make_game('morris', pieces=6, flying=False) builds a variant. Only games with options accept keywords."""
    table = {
        'tictactoe': TicTacToe,
        'connect4mini': lambda: Connect4(5, 5, 4),
        'connect4': lambda: Connect4(6, 7, 4),
        'othello6': lambda: Othello(6),
        'flock5': lambda: Flock(5, 5, 2),
        'flock6': lambda: Flock(6, 6, 3),
        'morris': Morris,
    }
    if name not in table:
        try:
            from .user_games import USER_GAMES            # games you added yourself (rlg/user_games.py)
            table.update(USER_GAMES)
        except ImportError:
            pass
    if name not in table:
        raise SystemExit('unknown game %r. choose from: %s' % (name, ', '.join(all_game_names())))
    try:
        return table[name](**kw)
    except TypeError:
        raise SystemExit('game %r does not take the options %s' % (name, sorted(kw)))


def all_game_names():
    try:
        from .user_games import USER_GAMES
    except ImportError:
        USER_GAMES = {}
    return GAMES + [g for g in USER_GAMES if g not in GAMES]


GAMES = ['tictactoe', 'connect4mini', 'connect4', 'othello6', 'flock5', 'flock6', 'morris']
