"""Export recorded games to ONE small JSON file that the Game Arena web page can play (up to 16 boards at once).
    python run.py export morris --sample 8                  # 8 random games from results/morris/games.jsonl (or the lab file)
    python run.py export morris --numbers 100,105-110       # these game numbers (see `python run.py replay morris --list`)
    python run.py export connect4 --label "vs perfect"      # only games whose label contains this text
Then open the Game Arena page, tab "Add games", and choose the file (or paste its text). Nothing else leaves your computer.

File format ("arena-1"): {"format": "arena-1", "games": [ one record per game ]}. A record has
    game      name of the game (tictactoe, connect4mini, othello6, flock5, morris, nim ... or your own name)
    shape     [rows, columns] for a grid game, null for Morris (24 points) or a list of piles (Nim)
    title     one line shown under the board, players  [name of first player, name of second player]
    winner    1 first player won, 2 second player won, 0 draw      why  how it ended
    cells     one string per position (the start plus one after every move): each character is one board cell, chr(66 + value)
              so value -1 is 'A', 0 is 'B', 1 is 'C', 2 is 'D' ...
    notes     one short text per move   hands  (Morris only) stones still to place, per position: [first, second]
Positions are stored directly, so the page needs no rules for any game and your own games can be shown too."""
import json, os, random
import numpy as np
from .games import make_game
from . import gamelog


def _cells(game, s):
    b = np.asarray(s.b).ravel()
    return ''.join(chr(66 + int(v)) for v in b)


def _shape(game):
    name = game.name
    if name.startswith('morris'):
        return None
    if name == 'nim':
        return None
    H, W = getattr(game, 'H', 0), getattr(game, 'W', 0)
    if name == 'tictactoe':
        return [3, 3]
    if name.startswith('othello') or name.startswith('flock'):
        return [game.n, game.n]
    if name.startswith('connect4'):
        return [game.H, game.W]
    return [H, W] if H > 1 and W > 1 else None


def record(game, g):
    """one logged game (from gamelog.load) -> one arena record"""
    s = game.initial(); cells = [_cells(game, s)]; notes = []; hands = [list(s.extra[:2])] if game.name.startswith('morris') else None
    for a in g['actions']:
        who = 'X' if s.turn == 1 else 'O'; notes.append('%s: %s' % (who, gamelog.action_text(game, int(a)))); s = game.step(s, int(a)); cells.append(_cells(game, s))
        if hands is not None:
            hands.append(list(s.extra[:2]))
    pl = g.get('players') or ['first player', 'second player']
    out = dict(game=game.name, shape=_shape(game), title=g['label'], players=pl, winner={1: 1, -1: 2, 0: 0}[int(g['winner'])], why=g['why'], cells=cells, notes=notes)
    if hands is not None:
        out['hands'] = hands
    return out


def parse_numbers(text):
    out = []
    for part in text.split(','):
        part = part.strip()
        if '-' in part:
            a, b = part.split('-'); out += list(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def export(name, path, numbers=None, sample=None, label=None, out_file=None, seed=0, max_moves=400):
    game = make_game(name); head, games = gamelog.load(path); nums = sorted(games)
    if label:
        nums = [n for n in nums if label.lower() in games[n]['label'].lower()]
    if numbers:
        nums = [n for n in numbers if n in games]
    elif sample:
        random.Random(seed).shuffle(nums); nums = sorted(nums[:sample])
    nums = [n for n in nums if len(games[n]['actions']) <= max_moves]
    if not nums:
        raise SystemExit('No games matched. Try `python run.py replay %s --list`.' % name)
    recs = []
    for n in nums:
        r = record(game, games[n]); r['title'] = '%s (game %d)' % (r['title'], n); recs.append(r)
    out_file = out_file or os.path.join(os.path.dirname(path) or '.', 'arena_%s.json' % name)
    json.dump({'format': 'arena-1', 'games': recs}, open(out_file, 'w'), separators=(',', ':'))
    print('Wrote %d games (%d KB) to %s' % (len(recs), os.path.getsize(out_file) // 1024, out_file))
    print('Open the Game Arena page, tab "Add games", and choose this file.')
    return out_file
