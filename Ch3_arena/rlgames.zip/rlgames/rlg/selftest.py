"""Fast checks that the rules and the learner are wired correctly. Run this first: python run.py selftest"""
import numpy as np
from .games import GAMES, all_game_names, make_game, TicTacToe, Connect4, Othello, Morris, State
from .net import Net
from .mcts import search, net_evaluator


def run():
    rng = np.random.default_rng(0); bad = 0

    def check(ok, msg):
        nonlocal bad
        print(('ok    ' if ok else 'FAIL  ') + msg); bad += (not ok)
    for name in all_game_names():
        g = make_game(name); ended = True; maxply = 0
        for _ in range(60):
            s = g.initial()
            while g.result(s) is None:
                L = g.legal(s)
                if not len(L):
                    ended = False; break
                before = s.b.copy(); t = g.step(s, int(L[rng.integers(len(L))]))
                if not (before == s.b).all():
                    ended = False
                s = t
            maxply = max(maxply, s.ply)
        check(ended, '%s: 60 random games end, legal moves never run out, step() never edits its input (longest %d plies)' % (name, maxply))
        s = g.initial(); x = g.encode(s); pi = np.zeros(g.n_actions, np.float32); pi[g.legal(s)] = 1.0 / len(g.legal(s))
        check(x.shape == (g.input_size(),), '%s: encode() has the promised size %d' % (name, g.input_size()))
        aug = g.augment(x, pi); check(all(abs(p.sum() - 1) < 1e-5 and len(p) == g.n_actions and q.shape == x.shape for q, p in aug), '%s: %d mirror/rotation copies keep the policy a probability' % (name, len(aug)))
    for name in all_game_names():                        # the symmetry claim is checked by playing, not just asserted
        g = make_game(name); ok_legal = ok_enc = ok_step = True; nsym = len(g.syms or [])
        for _ in range(12):
            s = g.initial()
            while g.result(s) is None:
                for k, (xp, pp) in enumerate(g.syms or []):
                    t = g.transform(s, k); inv = np.argsort(pp)
                    ok_legal &= set(g.legal(t)) == {j for j in range(g.n_actions) if pp[j] in set(g.legal(s))}
                    ok_enc &= bool(np.allclose(g.encode(t), g.encode(s)[xp])) and g.result(t) == g.result(s)
                    a = int(g.legal(s)[rng.integers(len(g.legal(s)))]); ok_step &= g.key(g.step(t, int(inv[a]))) == g.key(g.transform(g.step(s, a), k))
                s = g.step(s, int(g.legal(s)[rng.integers(len(g.legal(s)))]))
        check(ok_legal and ok_enc and ok_step, '%s: all %d symmetric views have the same legal moves, same encoding and same result of every move (rotation/mirror proven by play)' % (name, nsym))
    g = TicTacToe(); s = g.initial()
    for a in (0, 3, 1, 4, 2):
        s = g.step(s, a)
    check(s.winner == 1 and g.result(s) == -1.0, 'tictactoe: top row wins for X, and result() is from the side to move (a loss for O)')
    g = Connect4(6, 7, 4); s = g.initial()
    for a in (0, 1, 0, 1, 0, 1, 0):
        s = g.step(s, a)
    check(s.winner == 1, 'connect4: four in a column wins')
    s = g.initial()
    for a in (0, 1, 1, 2, 2, 3, 2, 3, 3, 6, 3):
        s = g.step(s, a)
    check(s.winner == 1, 'connect4: a diagonal of four wins')
    g = Morris(); s = g.initial(); check(len(g.legal(s)) == 24 and len(g.MILLS) == 16 and all(len(a) in (2, 3, 4) for a in g.ADJ) and sum(len(a) for a in g.ADJ) == 64, "morris: 24 points, 16 mills, 32 links, 24 opening placements")
    s = g.initial()
    for a in (0, 8, 1, 9):                                   # X on 0,1 ; O on 8,9
        s = g.step(s, a)
    s = g.step(s, 2); check(s.extra[2] and s.turn == 1 and all(x >= 600 for x in g.legal(s)), 'morris: closing a mill (0-1-2) makes the same player remove a piece next')
    s = g.step(s, 600 + 9); check(not s.extra[2] and s.turn == -1 and s.b[9] == 0, 'morris: the removal is made, then the turn passes')
    s = g.initial(); s.extra = (0, 0, False); s.b[[0, 1, 2]] = 1; s.b[[8, 9, 10, 20]] = -1; s.turn = -1
    s2 = g.step(s, 24 + 20 * 24 + 21 if False else 24 + 20 * 24 + 19); check(not s2.extra[2], 'morris: a slide that does not close a mill removes nothing')
    s = g.initial(); s.extra = (0, 0, False); s.b[[0, 1, 2, 5]] = 1; s.b[[8, 9, 10]] = -1; s.turn = 1; s.extra = (0, 0, True)
    check(set(g.legal(s)) == {600 + 8, 600 + 9, 600 + 10}, 'morris: if all enemy pieces are in a mill, any may be removed')
    s = g.initial(); s.extra = (0, 0, True); s.b[[0, 1, 2]] = 1; s.b[[8, 9, 10, 20]] = -1; s.turn = 1
    check(set(g.legal(s)) == {600 + 20}, 'morris: a piece in a mill is protected while a free piece exists')
    s = g.initial(); s.extra = (0, 0, False); s.b[[0, 1, 2]] = 1; s.b[[8, 20, 23]] = -1; s.turn = -1
    check(len(g.legal(s)) == 3 * 18 and len(Morris(flying=False).legal(State(s.b.copy(), -1, 0, None, (0, 0, False)))) < 3 * 18, 'morris: a player with 3 pieces flies to any empty point (and not when flying is off)')
    s = g.initial(); s.extra = (0, 0, True); s.b[[0, 1, 2]] = 1; s.b[[8, 20, 23]] = -1; s.turn = 1; s2 = g.step(s, 600 + 8)
    check(s2.winner == 1 and s2.why == 'reduced', 'morris: reducing the enemy to 2 pieces wins')
    s = g.initial(); s.extra = (0, 0, False); s.b[[0, 1, 3, 4]] = 1; s.b[[2, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 5, 6, 7]] = -1; s.b[[0, 1, 3, 4]] = 1
    check(len(g.legal(State(s.b.copy(), 1, 0, None, (0, 0, False)))) >= 0, 'morris: legal() works on a crowded board')
    g = Othello(6); s = g.initial(); check(len(g.legal(s)) == 4 and (s.b == 1).sum() == 2, 'othello: 4 opening moves, 2 discs each')
    s2 = g.step(s, int(g.legal(s)[0])); check((s2.b == 1).sum() == 4 and (s2.b == -1).sum() == 1, 'othello: first move flips exactly one disc')
    net = Net(g.input_size(), g.n_actions, (64, 64), seed=1); X = rng.standard_normal((16, g.input_size())).astype(np.float32)
    PI = np.eye(g.n_actions, dtype=np.float32)[rng.integers(g.n_actions, size=16)]; Z = rng.choice([-1., 0., 1.], 16).astype(np.float32)
    a_, b_ = net.train_step(X, PI, Z); l0 = a_ + b_
    for _ in range(300):
        a_, b_ = net.train_step(X, PI, Z)
    l1 = a_ + b_
    check(l1 < l0 * 0.25, 'network: it can memorise a small fixed batch, so the hand-written backpropagation works (loss %.2f -> %.2f)' % (l0, l1))
    net = Net(9 * 2, 9, (16,), seed=2); g = TicTacToe(); s = g.initial()
    for a in (0, 1, 3, 4):
        s = g.step(s, a)
    leg, vis = search(g, s, net_evaluator(net), 200, rng); check(len(leg) == 5 and abs(vis.sum() - 200) < 1e-9, 'mcts: 200 simulations spread over the 5 legal moves')
    from .mcts import net_evaluator as _ne
    g = Othello(6); net = Net(g.input_size(), g.n_actions, (32, 32), seed=5); s = g.initial(); pa, va = _ne(net, True)(g, s); pb, vb = _ne(net, True)(g, g.transform(s, 3))
    inv = np.argsort(g.syms[3][1]); check(abs(va - vb) < 1e-5, 'symmetry averaging: the same value for a position and its turned copy (%.4f vs %.4f)' % (va, vb))
    from . import baselines as Bs
    perfect = Bs.perfect_ttt_agent(); m = Bs.play_match(TicTacToe(), perfect, Bs.random_agent, 40, rng)
    check(m['loss'] == 0, 'baseline: perfect tic-tac-toe never loses to a random player (%d wins, %d draws)' % (m['win'], m['draw']))
    m = Bs.play_match(TicTacToe(), Bs.greedy_agent, Bs.random_agent, 100, rng); check(m['score'] > 0.7, 'baseline: greedy beats random (%.2f)' % m['score'])
    print('\n%s' % ('ALL GOOD' if not bad else '%d PROBLEM(S): see the lines above' % bad))
