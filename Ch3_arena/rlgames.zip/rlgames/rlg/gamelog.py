"""Game recorder and replayer.
Every game played by `train` and `lab` is saved as one line in a .jsonl file with a running number (1, 2, 3 ...).
    python run.py replay morris 100            # show game 100 move by move (press Enter for the next move)
    python run.py replay morris 100 --all      # print the whole game at once
    python run.py replay morris --list         # one line per game: number, label, result, length
A game is stored as its list of moves only, so a game costs a few hundred bytes. Replay re-plays the moves through the rules."""
import json, os

_rec = dict(f=None, n=0, label='', every=1)


def open_log(path, game_name, every=1):
    """start recording to `path` (overwrites). every=3 keeps only every 3rd game, for long runs."""
    close_log(); os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    _rec.update(f=open(path, 'w'), n=0, label='', every=max(1, every), seen=0)
    _rec['f'].write(json.dumps({'header': True, 'game': game_name}) + '\n')


def set_label(text):
    _rec['label'] = text


def record(actions, state, label=None, players=None):
    """called after each finished game. `actions` = the moves in order, `state` = the final state."""
    if _rec['f'] is None:
        return
    _rec['seen'] += 1
    if _rec['seen'] % _rec['every']:
        return
    _rec['n'] += 1
    line = {'n': _rec['n'], 'label': label or _rec['label'], 'actions': [int(a) for a in actions], 'winner': int(state.winner), 'why': state.why}
    if players:
        line['players'] = players                       # [name of the player who moved first, name of the second]
    _rec['f'].write(json.dumps(line) + '\n')


def close_log():
    if _rec['f'] is not None:
        _rec['f'].close(); _rec['f'] = None


def load(path):
    head, games = None, {}
    for line in open(path):
        d = json.loads(line)
        if d.get('header'):
            head = d
        else:
            games[d['n']] = d
    return head, games


# ------------------------------------------------------------------ describing a move in words
def action_text(game, a):
    if hasattr(game, 'action_text'):
        return game.action_text(a)
    name = game.name
    if name == 'tictactoe':
        return 'row %d, column %d' % (a // 3 + 1, a % 3 + 1)
    if name.startswith('connect4'):
        return 'drop in column %d' % (a + 1)
    if name.startswith('othello'):
        n = game.n
        return 'pass' if a == n * n else 'row %d, column %d' % (a // n + 1, a % n + 1)
    if name.startswith('flock'):
        n = game.n; f, t = divmod(a, n * n)
        return 'move (%d,%d) -> (%d,%d)' % (f // n + 1, f % n + 1, t // n + 1, t % n + 1)
    if name.startswith('morris'):
        if a < 24:
            return 'place a piece on point %d' % a
        if a < 600:
            f, t = divmod(a - 24, 24)
            return 'move point %d -> point %d' % (f, t)
        return 'REMOVE enemy piece on point %d' % (a - 600)
    return 'action %d' % a


def point_map(game):
    """Morris: the number of every point, drawn in the same layout as the board, so 'move point 7 -> point 15' can be followed."""
    order = [0, 1, 2, 8, 9, 10, 16, 17, 18, 7, 15, 23, 19, 11, 3, 22, 21, 20, 14, 13, 12, 6, 5, 4]       # points in reading order on the drawn board
    lines = game.render(game.initial()).split('\n')[:-1]; k = 0; out = ['Point numbers:']
    for ln in lines:
        row = ''
        for ch in ln:
            if ch == '.':
                row += '%2d' % order[k]; k += 1
            else:
                row += {'-': '--', '|': '| '}.get(ch, '  ')
        out.append(row)
    return '\n'.join(out)


def _render(game, s):
    try:
        return game.render(s)
    except Exception:                      # a game without its own render(): show the raw board numbers
        return str(s.b.tolist()) + '   extra=' + str(s.extra)


def _who(s):
    return 'X (first player)' if s.turn == 1 else 'O (second player)'


def list_games(path, limit=None):
    head, games = load(path); print('%s: %d games recorded (%s)' % (os.path.basename(path), len(games), head['game'] if head else '?'))
    for n in sorted(games)[:limit]:
        g = games[n]; res = {1: 'first player won', -1: 'second player won', 0: 'draw'}[g['winner']]
        print('  game %-5d %-60s %-18s %3d moves  (%s)' % (n, g['label'][:60], res, len(g['actions']), g['why']))


def replay(game, path, number, step=True, out=print, wait=input):
    """show game `number` move by move. step=True waits for Enter between moves."""
    head, games = load(path)
    if number not in games:
        ns = sorted(games); raise SystemExit('Game %d is not in %s (it holds games %d to %d).' % (number, path, ns[0], ns[-1]))
    g = games[number]; s = game.initial()
    out('Game %d   %s' % (number, g['label']))
    if g.get('players'):
        out('X (moves first) = %s     O = %s' % tuple(g['players']))
    out('%d moves. Result: %s (%s)\n' % (len(g['actions']), {1: 'X (first player) wins', -1: 'O (second player) wins', 0: 'draw'}[g['winner']], g['why']))
    if game.name.startswith('morris'):
        out(point_map(game) + '\n')
    out(_render(game, s))
    for k, a in enumerate(g['actions'], 1):
        if step:
            try:
                wait('\n[Enter = next move, Ctrl-C = stop] ')
            except (KeyboardInterrupt, EOFError):
                out('\nstopped.'); return
        else:
            out('')
        mover = _who(s); s = game.step(s, a)
        out('move %d: %s plays: %s' % (k, mover, action_text(game, a))); out(_render(game, s))
    out('\nEnd: ' + ({1: 'X (first player) wins', -1: 'O (second player) wins', 0: 'draw'}[s.winner]) + ' (%s)' % s.why)
    if s.winner != g['winner']:
        out('WARNING: replaying the moves gave a different result than the log. The rules may have changed since the games were recorded.')
