"""Small controlled experiments. Each one switches ONE ingredient off and trains again with the same number of self-play games and the same
random seed, then measures against the same fixed opponents. This is how you find out which ingredient was doing the work.
The names come from the strategy books (see the wiki page): the book gives the question, the experiment gives the answer."""
import os
import numpy as np
from . import train as T, baselines as B
from .games import make_game
from .net import Net

VARIANTS = {
    'baseline':       ({}, 'the full recipe'),
    'no_noise':       (dict(dirichlet=0.0), 'no random noise at the root: no feints, always the "main line" (奇正 / 聲東擊西)'),
    'no_temperature': (dict(temperature=0.0), 'always play the most-visited move in self-play: no variety (兵無常勢)'),
    'few_sims':       (dict(sims_scale=0.25), 'a quarter of the thinking per move while learning (多算勝,少算不勝)'),
    'no_augment':     (dict(augment=False), 'no rotation or mirror views: the learner has to meet every view by itself (舉一反三)'),
}


def score_vs(game, agent, opp, n, rng):
    return B.play_match(game, agent, opp, n, rng)['score']


def run(name, minutes, iters, seed, out_dir, which='all'):
    game = make_game(name); cfg = T.CONFIGS[name]; iters = iters or cfg['iters']
    names = list(VARIANTS) if which == 'all' else which.split(',')
    rows = []; best_net = None
    for v in names:
        sw, desc = VARIANTS[v]; print('\n=== %s: %s' % (v, desc), flush=True)
        folder, hist = T.train(name, minutes, iters, seed, out_dir, switches=sw, tag=v, quiet=False)
        net = Net.load(os.path.join(folder, 'model.npz')); rng = np.random.default_rng(seed + 99); n = max(20, cfg['eval_games'] * 2)
        agent = B.net_mcts_agent(net, cfg['eval_sims'])
        r = dict(variant=v, vs_random=score_vs(game, agent, B.random_agent, n, rng), vs_greedy=score_vs(game, agent, B.greedy_agent, n, rng), vs_rollout=score_vs(game, agent, B.rollout_mcts_agent(cfg['rollout']), n // 2, rng))
        if name == 'tictactoe':
            r['vs_perfect'] = score_vs(game, agent, B.perfect_ttt_agent(), n, rng)
        r['avg'] = float(np.mean([r['vs_random'], r['vs_greedy'], r['vs_rollout']])); r['first_move_variety'] = hist[-1]['first_move_variety']; rows.append(r)
        if v == 'baseline':
            best_net = net
    L = ['# Experiments: %s' % name, '', 'Same seed, same number of self-play games (%d iterations), same fixed opponents. One ingredient changed per row.' % iters, '',
         '| variant | what changed | vs random | vs greedy | vs rollout | ' + ('vs perfect | ' if name == 'tictactoe' else '') + 'average | opening variety |', '|---|---|---|---|---|' + ('---|' if name == 'tictactoe' else '') + '---|---|']
    for r in rows:
        L.append('| %s | %s | %.2f | %.2f | %.2f | %s%.2f | %.2f |' % (r['variant'], VARIANTS[r['variant']][1].split(':')[0], r['vs_random'], r['vs_greedy'], r['vs_rollout'], ('%.2f | ' % r['vs_perfect']) if 'vs_perfect' in r else '', r['avg'], r['first_move_variety']))
    if best_net is not None:                                         # how much does thinking at play time help the SAME network?
        L += ['', '## Thinking time at play (same trained network, more or less search) (多算勝)', '', '| simulations per move | vs random | vs greedy | vs rollout |', '|---|---|---|---|']
        rng = np.random.default_rng(seed + 7); n = max(20, cfg['eval_games'] * 2)
        for sims, tta in ((0, False), (5, False), (20, False), (80, False), (80, True)):
            agent = B.net_policy_agent(best_net) if sims == 0 else B.net_mcts_agent(best_net, sims, tta)
            L.append('| %s | %.2f | %.2f | %.2f |' % ('0 (instinct only)' if sims == 0 else ('%d + symmetry averaging (every turned view asked, answers averaged)' % sims if tta else sims), score_vs(game, agent, B.random_agent, n, rng), score_vs(game, agent, B.greedy_agent, n, rng), score_vs(game, agent, B.rollout_mcts_agent(cfg['rollout']), n // 2, rng)))
    L += ['', 'Honest note: with %d games per cell, a gap smaller than about 0.15 is noise. Repeat with --seed 1, 2 and compare before believing a small difference.' % (max(20, cfg['eval_games'] * 2))]
    os.makedirs(out_dir, exist_ok=True); path = os.path.join(out_dir, 'experiments_%s.md' % name); open(path, 'w').write('\n'.join(L) + '\n'); print('\n' + '\n'.join(L)); print('\nDone. The report is in', path)
