"""The functions the Game Arena web page calls. The page runs THIS package inside the browser (Pyodide = Python + NumPy compiled to WebAssembly),
so what you do on the page is exactly what `run.py` does on your computer. Nothing is uploaded: the files stay in your browser.

The page talks to this module with plain text (JSON) and base64, and keeps one small session here:
    set_model(path)        read a model.npz you chose (checked: only float arrays, sensible sizes, matches one of the games below)
    set_games(text)        read a games .jsonl file (checked: allowed game name, every move replayed through the rules)
    records_json(...)      the games to watch (boards as text, ready to draw)
    position_json(...)     the board after some moves, and the legal moves (for you to play against the model)
    ai_move_json(...)      the model's move (tree search guided by the network) and what it thinks of the position
    add_human_game(...)    remember a game you played, so the learner can use it
    learn_begin / learn_step   learn from the games (small steps, so the page stays responsive and can be stopped)
    export_*               the updated model, the updated games file, a report, or all of them in one zip
Every function is also usable from a normal Python shell, and `python run.py learn` calls the same learner."""
import base64, io, json, math, time, zipfile, collections
import numpy as np
from .games import make_game
from .net import Net
from .mcts import search, pick, net_evaluator
from . import arena, baselines as B
from . import train as T

PLAY = ['tictactoe', 'connect4mini', 'connect4', 'othello6', 'flock5', 'flock6', 'morris']   # games the page lets you play against a model
VIEW = PLAY + ['nim']                                                                         # games whose recorded games the page can show
MAX_GAMES, MAX_MOVES, MAX_TEXT, MAX_PARAMS = 3000, 400, 12_000_000, 3_000_000

SESSION = dict(name=None, net=None, net0=None, games={}, human=[], new_games=[], report='', learner=None, final=None)
PROGRESS = [None]


def reset():
    SESSION.update(name=None, net=None, net0=None, games={}, human=[], new_games=[], report='', learner=None, final=None)


def _b64(b):
    return base64.b64encode(b).decode('ascii')


# ---------------------------------------------------------------------------------------------------------------- reading files
def _read_model(data):
    """data = bytes of a .npz written by Net.save. Returns (net, games it fits). Raises ValueError with a plain message."""
    try:
        d = np.load(io.BytesIO(data), allow_pickle=False)           # allow_pickle=False: a file cannot smuggle in code
        files = list(d.files)
    except Exception:
        raise ValueError('this is not a model file. Choose the model.npz written by python run.py train.')
    if 'n' not in files:
        raise ValueError('this is not a model written by this code (no "n" entry)')
    try:
        k = int(d['n'])
        if not (1 <= k <= 6):
            raise ValueError('the model has %d hidden layers; between 1 and 6 are allowed' % k)
        ps = [d['arr_%d' % i] for i in range(2 * k + 4)]
    except ValueError:
        raise
    except Exception:
        raise ValueError('the arrays inside this model are missing or unreadable')
    if not (1 <= k <= 6):
        raise ValueError('the model has %d hidden layers; between 1 and 6 are allowed' % k)
    if any(p.dtype != np.float32 for p in ps):
        raise ValueError('the model must hold float32 numbers only')
    if sum(p.size for p in ps) > MAX_PARAMS:
        raise ValueError('this model is larger than the page allows (%d numbers)' % MAX_PARAMS)
    W, b, Wp, bp, Wv, bv = ps[:k], ps[k:2 * k], ps[2 * k], ps[2 * k + 1], ps[2 * k + 2], ps[2 * k + 3]
    din = W[0].shape[0]; nact = Wp.shape[1]; sizes = [din] + [w.shape[1] for w in W]
    ok = all(w.ndim == 2 and w.shape[0] == s for w, s in zip(W, sizes[:-1])) and all(x.shape == (s,) for x, s in zip(b, sizes[1:]))
    ok = ok and Wp.shape == (sizes[-1], nact) and bp.shape == (nact,) and Wv.shape == (sizes[-1], 1) and bv.shape == (1,)
    if not ok:
        raise ValueError('the arrays inside this model do not fit together')
    if not all(np.isfinite(p).all() for p in ps):
        raise ValueError('the model contains numbers that are not finite')
    fits = []
    for name in PLAY:
        g = make_game(name)
        if g.input_size() == din and g.n_actions == nact:
            fits.append(name)
    net = Net(din, nact, sizes[1:])
    for dst, src in zip(net.params(), ps):
        dst[...] = src
    return net, fits


def set_model(path, game=None):
    data = open(path, 'rb').read()
    if len(data) > 40_000_000:
        return json.dumps(dict(ok=False, error='model file is over 40 MB'))
    try:
        net, fits = _read_model(data)
    except ValueError as e:
        return json.dumps(dict(ok=False, error=str(e)))
    if not fits:
        return json.dumps(dict(ok=False, error='this model does not fit any game this page can play (%s)' % ', '.join(PLAY)))
    name = game if game in fits else fits[0]
    if SESSION['name'] not in (None, name):
        SESSION.update(games={}, human=[], new_games=[], learner=None, final=None, report='')
    SESSION.update(name=name, net=net, net0=net.copy(), learner=None, final=None, report='')
    hidden = [w.shape[1] for w in net.W]
    return json.dumps(dict(ok=True, game=name, fits=fits, hidden=hidden, params=int(sum(p.size for p in net.params()))))


def _replay_ok(game, g):
    """replay one logged game through the real rules. True only if every move is legal and the logged winner is what the rules say."""
    try:
        s = game.initial()
        for a in g['actions']:
            if int(a) not in set(int(x) for x in game.legal(s)):
                return False
            s = game.step(s, int(a))
        r = game.result(s)
        return r is not None and int(round(float(r) * s.turn)) == int(g['winner'])
    except Exception:
        return False


def set_games(text):
    """text = the content of a games .jsonl file (header line + one line per game)"""
    if len(text) > MAX_TEXT:
        return json.dumps(dict(ok=False, error='that file is over %d MB' % (MAX_TEXT // 1_000_000)))
    head, games, bad, seen = None, {}, 0, 0
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            d = json.loads(line)
        except ValueError:
            return json.dumps(dict(ok=False, error='this is not a games file (a line is not valid JSON)'))
        if not isinstance(d, dict):
            return json.dumps(dict(ok=False, error='this is not a games file'))
        if d.get('header'):
            head = d; continue
        seen += 1
        if seen > MAX_GAMES:
            break
        acts = d.get('actions')
        if not (isinstance(acts, list) and 0 < len(acts) <= MAX_MOVES and all(isinstance(a, int) and not isinstance(a, bool) for a in acts) and d.get('winner') in (-1, 0, 1) and isinstance(d.get('n'), int)):
            bad += 1; continue
        games[d['n']] = dict(n=d['n'], label=str(d.get('label', ''))[:100], actions=acts, winner=d['winner'], why=str(d.get('why', ''))[:30],
                             players=[str(x)[:30] for x in d['players'][:2]] if isinstance(d.get('players'), list) and len(d['players']) >= 2 else None)
    name = (head or {}).get('game')
    if name not in VIEW:
        return json.dumps(dict(ok=False, error='this games file is for "%s", which this page cannot show. Allowed: %s' % (str(name)[:30], ', '.join(VIEW))))
    if SESSION['name'] is not None and name != SESSION['name'] and SESSION['name'] in PLAY:
        return json.dumps(dict(ok=False, error='this games file is for %s but the model you loaded is for %s. Load a matching pair.' % (name, SESSION['name'])))
    g = make_game(name); ok = {}
    for n in sorted(games):
        if _replay_ok(g, games[n]):
            ok[n] = games[n]
        else:
            bad += 1
    if not ok:
        return json.dumps(dict(ok=False, error='no game in this file passed the rules check (%d checked)' % (len(games) + 0)))
    SESSION.update(name=name, games=ok, learner=None, final=None)
    return json.dumps(dict(ok=True, game=name, count=len(ok), skipped=bad, first=min(ok), last=max(ok), capped=seen > MAX_GAMES))


# ---------------------------------------------------------------------------------------------------------------- watching games
def parse_numbers(text):
    out = []
    for part in str(text).split(','):
        part = part.strip()
        try:
            if '-' in part:
                a, b = part.split('-'); out += list(range(int(a), min(int(b), int(a) + 200) + 1))
            elif part:
                out.append(int(part))
        except ValueError:
            continue
    return out[:200]


def records_json(numbers='', sample=48):
    """the games to draw: the numbers you typed (like '100,105-110'), or an even sample of the file"""
    name = SESSION['name']
    if not SESSION['games']:
        return json.dumps(dict(ok=False, error='load a games file first'))
    game = make_game(name); allg = SESSION['games']; nums = [n for n in parse_numbers(numbers) if n in allg]
    if not nums:
        keys = sorted(allg); step = max(1.0, len(keys) / float(sample)); nums = [keys[int(i * step)] for i in range(min(sample, len(keys)))]
    recs = []
    for n in nums:
        g = allg[n]
        r = arena.record(game, g); r['title'] = '%s (game %d)' % (g['label'] or 'game', n); recs.append(r)
    return json.dumps(dict(ok=True, game=name, games=recs, total=len(allg)))


# ---------------------------------------------------------------------------------------------------------------- playing against the model
def _describe(game, a):
    """(kind, from, to) of a move, so the page can let you click it. kinds: p place/drop/play, m move, x remove, s pass"""
    n = game.name
    if n == 'morris':
        if a < 24:
            return ('p', -1, a)
        if a < 600:
            return ('m', (a - 24) // 24, (a - 24) % 24)
        return ('x', -1, a - 600)
    if n.startswith('flock'):
        N = game.n * game.n; return ('m', a // N, a % N)
    if n.startswith('othello') and a == game.n * game.n:
        return ('s', -1, -2)
    return ('p', -1, a)


def position_json(actions_json):
    name = SESSION['name']; game = make_game(name); acts = json.loads(actions_json)
    if len(acts) > MAX_MOVES:
        return json.dumps(dict(ok=False, error='too many moves'))
    s = game.initial(); cells = [arena._cells(game, s)]; notes = []; hands = [list(s.extra[:2])] if name == 'morris' else None
    for a in acts:
        if int(a) not in set(int(x) for x in game.legal(s)):
            return json.dumps(dict(ok=False, error='illegal move %s' % a))
        notes.append('%s: %s' % ('X' if s.turn == 1 else 'O', arena.gamelog.action_text(game, int(a)))); s = game.step(s, int(a)); cells.append(arena._cells(game, s))
        if hands is not None:
            hands.append(list(s.extra[:2]))
    over = game.result(s) is not None
    legal = [] if over else [[int(a)] + list(_describe(game, int(a))) for a in game.legal(s)]
    out = dict(ok=True, game=name, cells=cells, notes=notes, turn=int(s.turn), over=over, legal=legal, hands=hands, shape=arena._shape(game))
    if over:
        out.update(winner=int(s.winner), why=s.why)
    return json.dumps(out)


def ai_move_json(actions_json, sims=60, seed=None):
    """the model's choice: search guided by the network. Also returns the network's own opinion (value: +1 = I am winning, from the side to move)"""
    name = SESSION['name']; game = make_game(name); net = SESSION['net']; acts = json.loads(actions_json); s = game.initial()
    for a in acts:
        s = game.step(s, int(a))
    if game.result(s) is not None:
        return json.dumps(dict(ok=False, error='the game is over'))
    rng = np.random.default_rng(seed); sims = int(max(2, min(int(sims), 400)))
    legal, visits = search(game, s, net_evaluator(net), sims, rng, noise=0.0); a = pick(legal, visits, 0, rng)
    _, v = net.predict(game.encode(s)); share = visits / visits.sum(); order = np.argsort(-share)[:3]
    return json.dumps(dict(ok=True, action=int(a), value=round(float(v), 3), top=[[int(legal[i]), round(float(share[i]), 3)] for i in order]))


def add_human_game(actions_json, winner, why, human_side, label=''):
    """remember a finished game you played. human_side = 1 if you moved first, -1 if second"""
    name = SESSION['name']; game = make_game(name); acts = [int(a) for a in json.loads(actions_json)]
    g = dict(n=0, label=str(label)[:100] or 'played by you against the model', actions=acts, winner=int(winner), why=str(why)[:30], players=['you', 'model'] if human_side == 1 else ['model', 'you'])
    if not _replay_ok(game, g):
        return json.dumps(dict(ok=False, error='that game did not pass the rules check'))
    SESSION['human'].append(g); SESSION['final'] = None
    return json.dumps(dict(ok=True, count=len(SESSION['human'])))


# ---------------------------------------------------------------------------------------------------------------- learning from games
def _examples_from_games(game, net, games, weight, win_copy=0.4, rng=None):
    """one (input, policy target, outcome) per position of each logged game.
    Outcome: +1 if the player to move went on to win, -1 lose, 0 draw (this trains the VALUE head).
    Moves made by the 'random' or 'greedy' players named in a game's player list are never copied (their luck is not a lesson).
    Policy target (the POLICY head): if the mover went on to WIN, mostly copy the move that was played (win_copy of the weight on it, the rest on what the network
    already thought; 0.4 by default: in my tests 0.3 to 0.5 worked as well as or better than 0.8); if the mover DREW, half and half; if the mover LOST, keep what the network already thought (do not copy a losing move, do not punish it either)."""
    out = []
    for g in games:
        s = game.initial(); who = g.get('players') or [None, None]
        for a in g['actions']:
            x = game.encode(s); L = game.legal(s); logits, _ = net.predict(x); l = logits[L]; e = np.exp(l - l.max()); own = np.zeros(game.n_actions, np.float32); own[L] = e / e.sum()
            z = 0.0 if g['winner'] == 0 else (1.0 if g['winner'] == s.turn else -1.0)
            w = win_copy if z > 0 else (win_copy / 2 if z == 0 else 0.0)
            if who[0 if s.turn == 1 else 1] in ('random', 'greedy'):    # never copy a move made by the weak fixed opponents (a lucky win teaches nothing)
                w = 0.0
            pi = (1 - w) * own; pi[int(a)] += w
            out.extend([(x, pi.astype(np.float32), z)] * weight); s = game.step(s, int(a))
    return out


def _evaluate_gen(game, name, net, sims, n, rng, label):
    """a generator: plays n games against each fixed opponent and yields progress; its return value is {opponent: score}"""
    opps = [('random', B.random_agent), ('greedy', B.greedy_agent)]
    if name == 'tictactoe':
        opps.append(('perfect', B.perfect_ttt_agent()))
    me = B.net_mcts_agent(net, sims); res = {}
    for oname, ag in opps:
        w = d = 0
        for g in range(n):
            s, acts, a_first = B.play_one(game, me, ag, g, rng); col = 1 if a_first else -1
            w += s.winner == col; d += s.winner == 0
            yield dict(msg='%s: game %d of %d against %s' % (label, g + 1, n, oname))
        res[oname] = (w + 0.5 * d) / n
    return res


def learn_begin(opts_json):
    """start a learning run on what is loaded: the model, the games file (optional) and the games you played (optional). Then call learn_step() until done."""
    o = dict(rounds=3, selfplay=6, sims=None, batches=None, lr=3e-4, eval_games=8, eval_sims=30, file_games=100, human_weight=3, seed=0, win_copy=0.4)
    o.update(json.loads(opts_json)); name = SESSION['name']
    if SESSION['net'] is None or name is None:
        return json.dumps(dict(ok=False, error='load a model first'))
    n_file = min(len(SESSION['games']), int(o['file_games'])); n_hum = len(SESSION['human'])
    if n_file + n_hum == 0 and int(o['selfplay']) == 0:
        return json.dumps(dict(ok=False, error='nothing to learn from: load a games file, play a game, or allow some self-play'))
    SESSION['learner'] = _learn_gen(name, o); SESSION['final'] = None
    return json.dumps(dict(ok=True))


def learn_step():
    """one small unit of work. returns {done, msg, pct}"""
    g = SESSION['learner']
    if g is None:
        return json.dumps(dict(done=True, msg='nothing running', pct=100))
    try:
        d = next(g); return json.dumps(dict(done=False, msg=d['msg'], pct=d.get('pct', 0)))
    except StopIteration:
        SESSION['learner'] = None; return json.dumps(dict(done=True, msg='finished', pct=100, report=SESSION['report']))
    except Exception as e:                                       # a bug should end the run with a message, not freeze the page
        SESSION['learner'] = None; return json.dumps(dict(done=True, error='%s: %s' % (type(e).__name__, e), pct=100))


def learn_cancel():
    SESSION['learner'] = None; return 'stopped'


def _learn_gen(name, o):
    game = make_game(name); cfg = dict(T.CONFIGS.get(name) or T.DEFAULT_CONFIG); sw = dict(T.SWITCHES)
    sims = int(o['sims'] or cfg['sims']); batches = int(o['batches'] or cfg['batches']); batch = cfg['batch']; rng = np.random.default_rng(int(o['seed']))
    net = SESSION['net0'].copy(); net.lr = float(o['lr']); R = int(o['rounds']); G = int(o['selfplay']); n_eval = int(o['eval_games']); esims = int(o['eval_sims'])
    total_steps = 2 * 3 * n_eval + R * (G + 1) + 2; done_steps = [0]

    def tick(msg):
        done_steps[0] += 1; return dict(msg=msg, pct=min(99, int(100 * done_steps[0] / total_steps)))
    # 1. how good is the model I was given? (fixed opponents never change, so before and after can be compared)
    before = yield from _eval_with_progress(game, name, SESSION['net0'], esims, n_eval, rng, 'before', tick)
    # 2. examples from the games
    keys = sorted(SESSION['games'])
    if o.get('file_pick', 'last') == 'last':                  # later games come from a better-trained model, so they are the better teachers
        pick_keys = keys[-int(o['file_games']):] if int(o['file_games']) > 0 else []
    else:
        step = max(1.0, len(keys) / float(max(1, int(o['file_games']))))
        pick_keys = [keys[int(i * step)] for i in range(min(len(keys), int(o['file_games'])))] if keys else []
    ex = _examples_from_games(game, SESSION['net0'], [SESSION['games'][k] for k in pick_keys], 1, float(o['win_copy']))
    ex_h = _examples_from_games(game, SESSION['net0'], SESSION['human'], int(o['human_weight']), float(o['win_copy']))
    buf = collections.deque(ex + ex_h, maxlen=max(cfg['buffer'], len(ex) + len(ex_h) + 1000)); new_games = []; losses = []
    yield tick('read %d games from the file and %d games you played: %d positions' % (len(pick_keys), len(SESSION['human']), len(buf)))
    first_loss = None
    for r in range(1, R + 1):
        for k in range(G):                                       # self-play with the current network
            out, fm, end, acts = T.self_play_game(game, net, dict(cfg, sims=sims), sw, rng); buf.extend(out)
            new_games.append(dict(label='learning self-play, round %d' % r, actions=[int(a) for a in acts], winner=int(end.winner), why=end.why, players=None))
            yield tick('round %d of %d: self-play game %d of %d' % (r, R, k + 1, G))
        lp = lv = 0.0
        if len(buf) >= 16:
            data = list(buf)
            for _ in range(batches):
                idx = rng.integers(len(data), size=min(batch, len(data))); X = []; PI = []
                for i in idx:
                    x, pi = data[i][0], data[i][1]
                    if game.syms:
                        xp, pp = game.syms[rng.integers(len(game.syms))]; x, pi = x[xp], pi[pp]
                    X.append(x); PI.append(pi)
                lp, lv = net.train_step(np.stack(X), np.stack(PI), np.array([data[i][2] for i in idx], np.float32))
        first_loss = first_loss or (lp, lv); losses.append((lp, lv))
        yield tick('round %d of %d: trained %d steps (loss: moves %.2f, who-wins %.2f)' % (r, R, batches, lp, lv))
    # 3. how good is it now?
    after = yield from _eval_with_progress(game, name, net, esims, n_eval, rng, 'after', tick)
    # 4. an extra check: the new model against the one I was given
    me, old = B.net_mcts_agent(net, esims), B.net_mcts_agent(SESSION['net0'], esims); w = d = 0; nvs = max(16, 2 * n_eval)
    for g in range(nvs):
        s, acts, a_first = B.play_one(game, me, old, g, rng); col = 1 if a_first else -1; w += s.winner == col; d += s.winner == 0
    vs_old = (w + 0.5 * d) / nvs
    SESSION['final'] = dict(net=net, new_games=new_games)
    SESSION['report'] = _report(name, o, before, after, vs_old, nvs, len(pick_keys), len(SESSION['human']), len(new_games), losses, sims, batches)
    yield dict(msg='finished', pct=100)


def _eval_with_progress(game, name, net, esims, n, rng, tag, tick):
    gen = _evaluate_gen(game, name, net, esims, n, rng, tag)
    while True:
        try:
            d = next(gen); yield tick(d['msg'])
        except StopIteration as e:
            return e.value


def _report(name, o, before, after, vs_old, nvs, n_file, n_hum, n_new, losses, sims, batches):
    L = ['# Learning report: %s' % name, '', '- Learned from: %d games of your file, %d games you played (counted %dx), and %d new self-play games.' % (n_file, n_hum, int(o['human_weight']), n_new),
         '- Settings: %d rounds, %d self-play games per round, %d search simulations per move, %d training steps per round, learning rate %s.' % (o['rounds'], o['selfplay'], sims, batches, o['lr']), '',
         '| opponent | before | after |', '|---|---|---|']
    for k in before:
        L.append('| %s | %.2f | %.2f |' % (k, before[k], after.get(k, float('nan'))))
    L += ['', '- New model against the model you gave me: %.2f (%d games; 0.50 = level).' % (vs_old, nvs),
          '- Training loss (moves, who-wins): first round %.2f / %.2f, last round %.2f / %.2f.' % (losses[0] + losses[-1]) if losses else '', '',
          '## How to read this', '',
          '- Score = wins plus half of the draws, out of 1. The opponents never change, so before and after can be compared.',
          '- With only %d games per opponent a change of less than about 0.2 is noise. If the new model is not clearly better, it is not proven worse either: train more, or keep the old one.' % int(o['eval_games']),
          '- Moves of the side that won were copied; moves of the side that lost were not. A weak player that wins by luck can teach a bad habit.']
    return '\n'.join(L) + '\n'


def adopt_updated():
    """make the updated model the current one, and fold your games and the new self-play games into the games file, so you can play it or learn again"""
    f = SESSION['final']
    if not f:
        return json.dumps(dict(ok=False, error='learn first'))
    n = max(SESSION['games']) if SESSION['games'] else 0
    for g in list(SESSION['human']) + list(f['new_games']):
        n += 1; SESSION['games'][n] = dict(n=n, label=g['label'], actions=g['actions'], winner=g['winner'], why=g['why'], players=g.get('players'))
    SESSION.update(net=f['net'], net0=f['net'].copy(), human=[], final=None, learner=None)
    return json.dumps(dict(ok=True, game=SESSION['name'], games=len(SESSION['games'])))


# ---------------------------------------------------------------------------------------------------------------- downloads
def _games_text(game_name, with_new=True):
    lines = [json.dumps({'header': True, 'game': game_name})]; n = 0
    for k in sorted(SESSION['games']):
        g = SESSION['games'][k]; n = max(n, k); d = dict(n=k, label=g['label'], actions=g['actions'], winner=g['winner'], why=g['why'])
        if g.get('players'):
            d['players'] = g['players']
        lines.append(json.dumps(d))
    extra = list(SESSION['human']) + (list((SESSION['final'] or {}).get('new_games', [])) if with_new else [])
    for g in extra:
        n += 1; d = dict(n=n, label=g['label'], actions=g['actions'], winner=g['winner'], why=g['why'])
        if g.get('players'):
            d['players'] = g['players']
        lines.append(json.dumps(d))
    return '\n'.join(lines) + '\n'


def export_model_b64(updated=True):
    net = (SESSION['final'] or {}).get('net') if updated else None; net = net or SESSION['net0']; buf = io.BytesIO(); net.save(buf); return _b64(buf.getvalue())


def export_games_text():
    return _games_text(SESSION['name'])


def export_report():
    return SESSION['report'] or '# No learning run yet\n'


def export_zip_b64():
    z = io.BytesIO()
    with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as f:
        f.writestr('model_updated.npz', base64.b64decode(export_model_b64(True))); f.writestr('model_original.npz', base64.b64decode(export_model_b64(False)))
        f.writestr('games_updated.jsonl', _games_text(SESSION['name'])); f.writestr('report.md', export_report())
    return _b64(z.getvalue())


def status_json():
    f = SESSION['final']
    return json.dumps(dict(game=SESSION['name'], has_model=SESSION['net'] is not None, file_games=len(SESSION['games']), human_games=len(SESSION['human']), learned=f is not None, new_games=len(f['new_games']) if f else 0))
