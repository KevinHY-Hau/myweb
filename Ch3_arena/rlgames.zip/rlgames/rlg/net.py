"""A small neural network in plain NumPy: shared layers, then a POLICY head (which move?) and a VALUE head (who is winning?).
No PyTorch needed. Backpropagation is written out by hand so you can read it. Adam is the optimiser."""
import numpy as np


class Net:
    def __init__(self, din, nact, hidden=(128, 128), lr=1e-3, seed=0):
        r = np.random.default_rng(seed); sizes = [din] + list(hidden)
        self.W = [(r.standard_normal((a, b)) * np.sqrt(2.0 / a)).astype(np.float32) for a, b in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros(b, np.float32) for b in sizes[1:]]
        h = sizes[-1]
        self.Wp = (r.standard_normal((h, nact)) * 0.01).astype(np.float32); self.bp = np.zeros(nact, np.float32)
        self.Wv = (r.standard_normal((h, 1)) * 0.1).astype(np.float32); self.bv = np.zeros(1, np.float32)
        self.lr, self.t = lr, 0
        self.m = [np.zeros_like(p) for p in self.params()]; self.v = [np.zeros_like(p) for p in self.params()]

    def params(self):
        return self.W + self.b + [self.Wp, self.bp, self.Wv, self.bv]

    def forward(self, X):
        hs = [X]; a = X
        for W, b in zip(self.W, self.b):
            a = np.maximum(0, a @ W + b); hs.append(a)
        return hs, a @ self.Wp + self.bp, np.tanh(a @ self.Wv + self.bv)[:, 0]

    def predict(self, x):
        _, logits, v = self.forward(x[None]); return logits[0], float(v[0])

    def train_step(self, X, PI, Z, l2=1e-4):
        """one gradient step on a batch. X inputs, PI target move distribution (from search), Z target outcome (+1 win, 0 draw, -1 loss)."""
        B = len(X); hs, logits, v = self.forward(X)
        z = logits - logits.max(1, keepdims=True); p = np.exp(z); p /= p.sum(1, keepdims=True)
        loss_p = float(-(PI * np.log(p + 1e-9)).sum(1).mean()); loss_v = float(((v - Z) ** 2).mean())
        dlog = (p - PI) / B                                  # gradient of cross-entropy w.r.t. the logits
        dv = (2 * (v - Z) / B * (1 - v ** 2))[:, None]       # gradient of squared error through tanh
        a = hs[-1]
        gWp, gbp, gWv, gbv = a.T @ dlog, dlog.sum(0), a.T @ dv, dv.sum(0)
        da = dlog @ self.Wp.T + dv @ self.Wv.T
        gW, gb = [None] * len(self.W), [None] * len(self.W)
        for i in reversed(range(len(self.W))):
            da = da * (hs[i + 1] > 0)
            gW[i], gb[i] = hs[i].T @ da, da.sum(0)
            da = da @ self.W[i].T
        grads = gW + gb + [gWp, gbp, gWv, gbv]
        self.t += 1; b1, b2 = 0.9, 0.999
        for k, (p_, g) in enumerate(zip(self.params(), grads)):
            if p_.ndim == 2:
                g = g + l2 * p_
            self.m[k] = b1 * self.m[k] + (1 - b1) * g; self.v[k] = b2 * self.v[k] + (1 - b2) * g * g
            p_ -= (self.lr * (self.m[k] / (1 - b1 ** self.t)) / (np.sqrt(self.v[k] / (1 - b2 ** self.t)) + 1e-8)).astype(np.float32)
        return loss_p, loss_v

    def save(self, path):
        np.savez(path, n=len(self.W), *self.params())

    @staticmethod
    def load(path):
        d = np.load(path); k = int(d['n']); ps = [d['arr_%d' % i] for i in range(len(d.files) - 1)]
        net = Net(ps[0].shape[0], ps[2 * k].shape[1], [w.shape[1] for w in ps[:k]])
        for dst, src in zip(net.params(), ps):
            dst[...] = src
        return net

    def copy(self):
        o = Net(self.W[0].shape[0], self.Wp.shape[1], [w.shape[1] for w in self.W])
        for dst, src in zip(o.params(), self.params()):
            dst[...] = src
        return o
