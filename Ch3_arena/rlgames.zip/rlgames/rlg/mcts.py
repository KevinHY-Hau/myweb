"""Monte Carlo tree search (PUCT), the 'thinking ahead' part. It does not care which game it is playing.
An evaluator is any function  f(game, state) -> (prior over the legal moves, value for the player to move).
The network is one evaluator; random play-outs (baselines.py) are another."""
import math
import numpy as np


class Node:
    __slots__ = ('state', 'legal', 'P', 'N', 'W', 'ch', 'term', 'expanded')

    def __init__(self, state):
        self.state = state; self.expanded = False; self.term = None; self.ch = {}


def net_evaluator(net, tta=False):
    """tta = 'test-time augmentation': ask the network about every turned/mirrored view of the position and average the answers.
    Costs 8x (or 2x) the network time per look, and removes the network's accidental preference for one corner."""
    def f(game, s):
        legal = game.legal(s); x = game.encode(s)
        if tta and game.syms:
            _, L, V = net.forward(np.stack([x[xp] for xp, pp in game.syms])); logits = np.zeros(game.n_actions)
            for k, (xp, pp) in enumerate(game.syms):
                logits[pp] += L[k]                           # entry j of the turned view is entry pp[j] of the real position
            logits /= len(game.syms); v = float(V.mean())
        else:
            logits, v = net.predict(x)
        l = logits[legal]; e = np.exp(l - l.max()); return e / e.sum(), v
    return f


def _expand(game, node, evaluator):
    s = node.state; r = game.result(s)
    if r is not None:
        node.term = r; node.expanded = True; return r
    node.legal = game.legal(s); P, v = evaluator(game, s)
    node.P = P.astype(np.float64); n = len(node.legal); node.N = np.zeros(n); node.W = np.zeros(n); node.expanded = True
    return v


def search(game, state, evaluator, sims, rng, c_puct=1.5, noise=0.0, alpha=0.3):
    """returns (legal_moves, visit_counts). `noise` > 0 mixes random Dirichlet noise into the root priors (exploration)."""
    root = Node(state); _expand(game, root, evaluator)
    if root.term is not None:
        return np.array([], int), np.array([])
    if noise > 0 and len(root.legal) > 1:
        root.P = (1 - noise) * root.P + noise * rng.dirichlet([alpha] * len(root.legal))
    for _ in range(sims):
        node, path = root, []
        while node.expanded and node.term is None:
            tot = node.N.sum(); q = np.divide(node.W, node.N, out=np.zeros_like(node.W), where=node.N > 0)
            i = int(np.argmax(q + c_puct * node.P * math.sqrt(tot + 1) / (1 + node.N)))
            path.append((node, i)); child = node.ch.get(i)
            if child is None:
                child = Node(game.step(node.state, node.legal[i])); node.ch[i] = child
            node = child
        v = node.term if node.term is not None else _expand(game, node, evaluator)
        for parent, i in reversed(path):                    # the value flips sign each step up: my gain is your loss
            v = -v; parent.N[i] += 1; parent.W[i] += v
    return root.legal, root.N


def pick(legal, visits, temperature, rng):
    if temperature <= 1e-6 or len(legal) == 1:
        best = np.flatnonzero(visits == visits.max()); return int(legal[rng.choice(best)])
    p = visits ** (1.0 / temperature); p = p / p.sum(); return int(legal[rng.choice(len(legal), p=p)])
