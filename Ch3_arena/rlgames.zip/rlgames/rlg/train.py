"""The learning loop:  play yourself (with search)  ->  learn from what the search found  ->  measure against fixed opponents  ->  repeat.
Writes results/<game>/metrics.csv, model.npz and report.md. Nothing else is needed."""
import csv, os, time, collections
import numpy as np
from .games import make_game
from .net import Net
from .mcts import search, pick, net_evaluator
from . import baselines as B, gamelog

# Every setting that matters, per game. Small games first: they finish in minutes.
CONFIGS = {
    'tictactoe':    dict(sims=60, games=20, batches=80,  batch=64, hidden=(64, 64),   buffer=4000,  temp_moves=4,  iters=100, eval_every=10, eval_games=30, eval_sims=100, rollout=100),
    'connect4mini': dict(sims=40, games=40, batches=120, batch=64, hidden=(96, 96),   buffer=10000, temp_moves=6,  iters=60, eval_every=6, eval_games=20, eval_sims=60, rollout=150),
    'connect4':     dict(sims=60, games=50, batches=150, batch=96, hidden=(128, 128), buffer=25000, temp_moves=8,  iters=80, eval_every=8, eval_games=20, eval_sims=80, rollout=150),
    'othello6':     dict(sims=50, games=40, batches=150, batch=96, hidden=(128, 128), buffer=25000, temp_moves=10, iters=80, eval_every=8, eval_games=16, eval_sims=60, rollout=60),
    'flock5':       dict(sims=40, games=40, batches=120, batch=96, hidden=(128, 128), buffer=20000, temp_moves=12, iters=80, eval_every=10, eval_games=12, eval_sims=50, rollout=25),
    'morris':       dict(sims=40, games=20, batches=100, batch=96, hidden=(128, 128), buffer=25000, temp_moves=16, iters=80, eval_every=10, eval_games=10, eval_sims=40, rollout=20),   # slow and hard: games are long
    'flock6':       dict(sims=40, games=30, batches=120, batch=96, hidden=(160, 160), buffer=20000, temp_moves=12, iters=80, eval_every=10, eval_games=10, eval_sims=50, rollout=20),
}
DEFAULT_CONFIG = dict(sims=40, games=20, batches=80, batch=64, hidden=(96, 96), buffer=8000, temp_moves=6, iters=40, eval_every=5, eval_games=16, eval_sims=50, rollout=60)   # used for games you add yourself
# switches the experiments flip (see experiments.py). Defaults = the full recipe.
SWITCHES = dict(dirichlet=0.25, temperature=1.0, augment=True, sims_scale=1.0)


def self_play_game(game, net, cfg, sw, rng):
    ev = net_evaluator(net); s = game.initial(); hist = []; acts = []; sims = max(2, int(cfg['sims'] * sw['sims_scale'])); first_move = None
    while game.result(s) is None:
        legal, visits = search(game, s, ev, sims, rng, noise=sw['dirichlet'])
        T = sw['temperature'] if s.ply < cfg['temp_moves'] else 0.0
        a = pick(legal, visits, T, rng)
        if first_move is None:
            first_move = a
        pi = np.zeros(game.n_actions, np.float32); pi[legal] = visits / visits.sum()
        hist.append((game.encode(s), pi, s.turn)); acts.append(a); s = game.step(s, a)
    out = []
    for x, pi, turn in hist:
        z = 0.0 if s.winner == 0 else (1.0 if s.winner == turn else -1.0)
        out.append((x, pi, z))                  # stored once; turned/mirrored at random when it is used for training (see train())
    return out, first_move, s, acts


DEFAULT_WORKERS = 1            # run.py sets this from --workers (self-play games run in parallel on several CPU cores)
_W = {}                        # per-worker cache: the game and a network skeleton


def _worker_play(job):
    """one self-play game in a worker process. job = (game name, network weights, config, switches, seed)"""
    name, params, cfg, sw, seed = job
    if _W.get('name') != name:
        g = make_game(name); _W.update(name=name, game=g, net=Net(g.input_size(), g.n_actions, cfg['hidden']))
    net = _W['net']
    for dst, src in zip(net.params(), params):
        dst[...] = src
    ex, fm, end, acts = self_play_game(_W['game'], net, cfg, sw, np.random.default_rng(seed))
    return ex, fm, end.winner, end.why, acts


class _End:
    def __init__(self, winner, why):
        self.winner, self.why = winner, why


def auto_workers():
    """a sensible default: half the logical CPUs (that is the number of real cores on most PCs), at least 1, at most 8"""
    return max(1, min(8, (os.cpu_count() or 2) // 2))


class _Fin:
    def __init__(self, winner, why):
        self.winner, self.why = winner, why


def _agent_from(spec, game, cfg):
    """build an opponent from a plain description (so it can be sent to a worker process)"""
    kind = spec[0]
    if kind == 'random':
        return B.random_agent
    if kind == 'greedy':
        return B.greedy_agent
    if kind == 'rollout':
        return B.rollout_mcts_agent(spec[1])
    if kind == 'perfect':
        return B.perfect_ttt_agent()
    net = Net(game.input_size(), game.n_actions, cfg['hidden'])
    for dst, src in zip(net.params(), spec[1]):
        dst[...] = src
    return B.net_policy_agent(net) if kind == 'instinct' else B.net_mcts_agent(net, spec[2], spec[3])


def _worker_eval(job):
    name, cfg, sa, sb, g, seed = job
    if _W.get('name') != name:
        gm = make_game(name); _W.update(name=name, game=gm, net=Net(gm.input_size(), gm.n_actions, cfg['hidden']))
    game = _W['game']; s, acts, a_first = B.play_one(game, _agent_from(sa, game, cfg), _agent_from(sb, game, cfg), g, np.random.default_rng(seed))
    return _Fin(s.winner, s.why), acts, a_first


def _match(game, name, cfg, pool, rng, sa, sb, games, names):
    """play `games` games of A (spec sa) against B (spec sb), on the pool if there is one"""
    if pool is None:
        return B.play_match(game, _agent_from(sa, game, cfg), _agent_from(sb, game, cfg), games, rng, names)
    seeds = rng.integers(0, 2**31 - 1, size=games)
    return B.tally(pool.map(_worker_eval, [(name, cfg, sa, sb, g, int(seeds[g])) for g in range(games)], chunksize=1), names)


def evaluate(game, net, prev, cfg, rng, name, tta=False, it=0, pool=None):
    n = cfg['eval_games']; row = {}; P = net.params(); me = ('net', P, cfg['eval_sims'], tta)
    lab = lambda opp: gamelog.set_label('check after iteration %d: network (with search) vs %s' % (it, opp))
    lab('random'); row['vs_random'] = _match(game, name, cfg, pool, rng, me, ('random',), n, ('network', 'random'))['score']
    lab('greedy'); row['vs_greedy'] = _match(game, name, cfg, pool, rng, me, ('greedy',), n, ('network', 'greedy'))['score']
    lab('rollout search'); row['vs_rollout'] = _match(game, name, cfg, pool, rng, me, ('rollout', cfg['rollout']), max(4, n // 2), ('network', 'rollout search'))['score']
    gamelog.set_label('check after iteration %d: instinct (network, no search) vs random' % it); row['instinct_vs_random'] = _match(game, name, cfg, pool, rng, ('instinct', P), ('random',), n, ('instinct', 'random'))['score']
    if name == 'tictactoe':
        lab('PERFECT player'); m = _match(game, name, cfg, pool, rng, me, ('perfect',), n, ('network', 'perfect')); row['vs_perfect'] = m['score']; row['lost_to_perfect'] = m['loss']
    if prev is not None:
        lab('the previous network'); row['vs_previous'] = _match(game, name, cfg, pool, rng, me, ('net', prev.params(), cfg['eval_sims'], False), max(4, n // 2), ('network', 'previous network'))['score']
    else:
        row['vs_previous'] = ''
    return row


def train(name, minutes=None, iters=None, seed=0, out_dir='results', switches=None, tag='', quiet=False, cfg_over=None, keep_every=1, workers=None):
    game = make_game(name); cfg = dict(CONFIGS.get(name) or DEFAULT_CONFIG); cfg.update(cfg_over or {}); sw = dict(SWITCHES); sw.update(switches or {})
    iters = iters or cfg['iters']; rng = np.random.default_rng(seed); workers = DEFAULT_WORKERS if workers is None else workers
    pool = None
    if workers > 1 and name in CONFIGS:                  # games you added yourself run on one core unless they are importable by name in every worker (they are: make_game finds user_games)
        import multiprocessing as mp; pool = mp.get_context('spawn').Pool(workers)
    net = Net(game.input_size(), game.n_actions, cfg['hidden'], seed=seed); buf = collections.deque(maxlen=cfg['buffer'])
    folder = os.path.join(out_dir, name + (('_' + tag) if tag else '')); os.makedirs(folder, exist_ok=True)
    t0 = time.time(); prev = net.copy(); rows = []; firsts = collections.Counter(); total_games = 0; why_total = collections.Counter()
    cols = ['iter', 'minutes', 'games', 'examples', 'loss_policy', 'loss_value', 'vs_random', 'vs_greedy', 'vs_rollout', 'instinct_vs_random', 'vs_perfect', 'lost_to_perfect', 'vs_previous', 'first_move_variety']
    gamelog.open_log(os.path.join(folder, 'games.jsonl'), name, keep_every)
    f = open(os.path.join(folder, 'metrics.csv'), 'w', newline=''); w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
    for it in range(1, iters + 1):
        firsts.clear()
        gamelog.set_label('training self-play, iteration %d' % it)
        if pool is not None:
            params = net.params(); seeds = rng.integers(0, 2**31 - 1, size=cfg['games'])
            results = pool.map(_worker_play, [(name, params, cfg, sw, int(sd)) for sd in seeds], chunksize=1)
        else:
            results = []
            for _ in range(cfg['games']):
                ex, fm, end, acts = self_play_game(game, net, cfg, sw, rng); results.append((ex, fm, end.winner, end.why, acts))
        for ex, fm, winner, why, acts in results:
            gamelog.record(acts, _End(winner, why)); buf.extend(ex); firsts[fm] += 1; total_games += 1; why_total[why] += 1
        lp = lv = 0.0
        if len(buf) >= cfg['batch']:
            data = list(buf)
            for _ in range(cfg['batches']):
                idx = rng.integers(len(data), size=cfg['batch']); X = []; PI = []
                for i in idx:
                    x, pi = data[i][0], data[i][1]
                    if sw['augment'] and game.syms:                      # symmetry: show this position through a random rotation / mirror
                        xp, pp = game.syms[rng.integers(len(game.syms))]; x, pi = x[xp], pi[pp]
                    X.append(x); PI.append(pi)
                X = np.stack(X); PI = np.stack(PI); Z = np.array([data[i][2] for i in idx], np.float32)
                lp, lv = net.train_step(X, PI, Z)
        mins = (time.time() - t0) / 60; last = minutes is not None and mins >= minutes
        if it % cfg['eval_every'] == 0 or it == iters or last:
            row = evaluate(game, net, prev, cfg, rng, name, it=it, pool=pool); prev = net.copy(); net.save(os.path.join(folder, 'model.npz'))
        else:
            row = {}
        pv = np.array(list(firsts.values()), float); variety = float(-(pv / pv.sum() * np.log(pv / pv.sum())).sum() / max(1e-9, np.log(max(2, len(pv))))) if len(pv) > 1 else 0.0
        row.update(iter=it, minutes=round(mins, 2), games=total_games, examples=len(buf), loss_policy=round(lp, 3), loss_value=round(lv, 3), first_move_variety=round(variety, 2))
        w.writerow(row); f.flush(); rows.append(row)
        if not quiet:
            print('iter %3d  %5.1f min  games %4d  loss p %.2f v %.2f  %s' % (it, mins, total_games, lp, lv, '  '.join('%s %.2f' % (k, row[k]) for k in ('vs_random', 'vs_greedy', 'vs_rollout', 'vs_previous', 'vs_perfect') if row.get(k, '') != '')), flush=True)
        if last:
            break
    if pool is not None:
        pool.close(); pool.join()
    f.close(); gamelog.close_log(); net.save(os.path.join(folder, 'model.npz'))
    write_report(name, folder, cfg, sw, rows, why_total, time.time() - t0, total_games)
    return folder, rows


def write_report(name, folder, cfg, sw, rows, why, secs, games):
    ev = [r for r in rows if r.get('vs_random', '') != '']
    L = ['# Results: %s' % name, '', 'Nothing private is in this file.', '',
         '- Time: %.1f minutes, %d self-play games, %d training steps per iteration' % (secs / 60, games, cfg['batches']),
         '- Settings: ' + ', '.join('%s=%s' % (k, v) for k, v in cfg.items()), '- Switches: ' + ', '.join('%s=%s' % (k, v) for k, v in sw.items()),
         '- How the self-play games ended: ' + ', '.join('%s %d' % kv for kv in why.most_common()), '',
         '| iter | min | games | vs random | vs greedy | vs rollout | instinct vs random | vs previous |' + (' vs perfect | lost to perfect |' if name == 'tictactoe' else ''),
         '|---|---|---|---|---|---|---|---|' + ('---|---|' if name == 'tictactoe' else '')]
    for r in ev:
        L.append('| %d | %.1f | %d | %.2f | %.2f | %.2f | %.2f | %s |' % (r['iter'], r['minutes'], r['games'], r['vs_random'], r['vs_greedy'], r['vs_rollout'], r['instinct_vs_random'], ('%.2f' % r['vs_previous']) if r['vs_previous'] != '' else '-') + ((' %.2f | %d |' % (r['vs_perfect'], r['lost_to_perfect'])) if name == 'tictactoe' else ''))
    if ev:
        a, z = ev[0], ev[-1]
        L += ['', '## Short reading (written by the program, not by a person)', '',
              '- Score = wins + half of draws, out of 1. 0.50 means level. Opponents never change, so this is a fair yardstick.',
              '- First check %d vs last check %d: vs random %.2f to %.2f, vs greedy %.2f to %.2f, vs rollout %.2f to %.2f.' % (a['iter'], z['iter'], a['vs_random'], z['vs_random'], a['vs_greedy'], z['vs_greedy'], a['vs_rollout'], z['vs_rollout']),
              '- "instinct" = the network alone with no search: %.2f vs random at the end. Search on top gives %.2f.' % (z['instinct_vs_random'], z['vs_random']),
              '- Opening variety (1 = tries many first moves, 0 = always the same), last iteration: %.2f.' % rows[-1]['first_move_variety']]
        L.append('- Verdict: ' + ('learned something real (beats the 1-ply greedy player more than half the time)' if z['vs_greedy'] > 0.6 else 'not clearly better than a simple greedy player yet; train longer or raise sims.'))
    open(os.path.join(folder, 'report.md'), 'w').write('\n'.join(L) + '\n')
