"""GAME LAB. Give it any game written to the rlg.games.Game interface; it plays the game thousands of times with players of different strength
and writes a report: is the game healthy, how much is skill and how much luck, which opening matters, what predicts winning, and does the usual
advice for this kind of game agree with the data. It does NOT understand the game; it measures it. Every number says how many games it rests on."""
import itertools, os, time, collections
import numpy as np
from .games import make_game
from . import baselines as B, gamelog

FOLK = {   # advice people give for each family of game, and the feature each piece of advice predicts will help (+) or hurt (-)
    'mill / placement': [('keep more pieces than the opponent', 'my_total', +1), ('block the opponent pieces so they cannot move', 'opp_blocked', +1),
                         ("do not get your own pieces blocked in", 'my_blocked', -1), ('keep two-in-a-row threats open', 'my_open_pairs', +1), ('close mills', 'my_mills', +1)],
    'connect': [('control the centre', 'my_centre', +1), ('keep your pieces linked', 'my_links', +1), ('keep your options open (more moves)', 'my_moves', +1)],
    'surround': [('keep more moves than the opponent (mobility)', 'my_moves', +1), ('do not just grab pieces early', 'my_pieces', -1)],
    'capture + reach': [('keep your pieces together', 'my_links', +1), ('keep more pieces', 'my_pieces', +1), ('keep more moves', 'my_moves', +1)],
}


def _agents(quick):
    lo, hi = (4, 16) if quick else (8, 40)
    return dict(random=B.random_agent, greedy=B.greedy_agent, weak=B.rollout_mcts_agent(lo, cap=40), strong=B.rollout_mcts_agent(hi, cap=40)), lo, hi


def play_record(game, a1, a2, rng, want_pos=False):
    s = game.initial(); pos = []; branch = []; acts = []
    while game.result(s) is None:
        L = game.legal(s); branch.append(len(L))
        if want_pos:
            pos.append((game.features(s), s.turn, s.ply))
        a = (a1 if s.turn == 1 else a2)(game, s, rng); acts.append(a); s = game.step(s, a)
    gamelog.record(acts, s)
    return s, pos, branch


def tactics_density(game, rng, games=30):
    """share of positions where some legal move wins on the spot. High = sharp tactical game. Low = quiet game."""
    hit = tot = 0
    for _ in range(games):
        s = game.initial()
        while game.result(s) is None:
            L = game.legal(s); tot += 1
            hit += any(game.step(s, a).winner == s.turn for a in L)
            s = game.step(s, int(L[rng.integers(len(L))]))
    return hit / max(1, tot)


def health(game, rng, quick, log=print):
    ag, lo, hi = _agents(quick); n_rand = 150 if quick else 400; n = 8 if quick else 20; out = {}
    t = time.time(); lens = []; br = []; why = collections.Counter(); w1 = d = 0
    gamelog.set_label('health check: random player vs random player')
    for _ in range(n_rand):
        s, _, b = play_record(game, ag['random'], ag['random'], rng); lens.append(s.ply); br += b; why[s.why] += 1; w1 += s.winner == 1; d += s.winner == 0
    out.update(random_games=n_rand, rand_len=float(np.mean(lens)), branching=float(np.mean(br)), rand_why=dict(why), rand_p1=w1 / n_rand, rand_draw=d / n_rand)
    out['tactics'] = tactics_density(game, rng, 15 if quick else 40); log('  random games done (%.0fs)' % (time.time() - t))
    t = time.time(); w1 = d = 0; lens = []; why = collections.Counter()
    gamelog.set_label('health check: weak search vs weak search')
    for _ in range(n):
        s, _, _ = play_record(game, ag['weak'], ag['weak'], rng); lens.append(s.ply); w1 += s.winner == 1; d += s.winner == 0; why[s.why] += 1
    out.update(weak_games=n, weak_len=float(np.mean(lens)), weak_p1=(w1 + 0.5 * d) / n, weak_draw=d / n, weak_why=dict(why)); log('  search-vs-search games done (%.0fs)' % (time.time() - t))
    ladder = {}
    for name, a, b in (('greedy vs random', 'greedy', 'random'), ('weak search vs random', 'weak', 'random'), ('strong search vs weak search', 'strong', 'weak'), ('strong search vs greedy', 'strong', 'greedy')):
        t = time.time(); gamelog.set_label('skill ladder: ' + name); m = B.play_match(game, ag[a], ag[b], n, rng, (a + ' search' if a in ('weak', 'strong') else a, b + ' search' if b in ('weak', 'strong') else b)); ladder[name] = (m['score'], m['win'], m['draw'], m['loss']); log('  %s: %.2f (%.0fs)' % (name, m['score'], time.time() - t))
    out['ladder'] = ladder; out['n'] = n; out['lo'] = lo; out['hi'] = hi
    return out


def openings(game, rng, quick, log=print):
    ag, lo, hi = _agents(quick); s0 = game.initial(); L = [int(a) for a in game.legal(s0)]; k = 3 if quick else 6
    inv = [np.argsort(pp) for xp, pp in (game.syms or [(None, np.arange(game.n_actions))])]
    orbit = {}                                                  # group first moves that are the same move turned or mirrored
    for a in L:
        orbit.setdefault(min(int(q[a]) for q in inv), []).append(a)
    reps = [v[0] for v in orbit.values()]; table = []
    for a in reps:
        sc = 0
        for g in range(k):
            s = game.step(s0, a)
            while game.result(s) is None:
                s = game.step(s, ag['weak'](game, s, rng))
            sc += 1.0 if s.winner == 1 else 0.5 if s.winner == 0 else 0.0
        table.append((a, len(orbit[min(int(q[a]) for q in inv)]), sc / k))
    log('  openings tried: %d kinds out of %d first moves' % (len(reps), len(L)))
    return dict(total=len(L), kinds=len(reps), table=sorted(table, key=lambda r: -r[2]), games_each=k)


def collect(game, a1, a2, n, rng):
    X, Z, P = [], [], []
    for _ in range(n):
        s, pos, _ = play_record(game, a1, a2, rng, want_pos=True)
        for f, turn, ply in pos:
            f = dict(f); f['__ply'] = float(ply); X.append(f); Z.append(0.0 if s.winner == 0 else (1.0 if s.winner == turn else -1.0)); P.append(ply / max(1, s.ply))
    return X, np.array(Z), np.array(P)


def fit_model(X, Z, P, rng, mask=None, ridge=5.0, hold=True):
    """standardised ridge regression of the result (-1 loss .. +1 win, for the player to move) on the game's features"""
    allnames = sorted({k for f in X for k in f if k != '__ply'}); M0 = np.array([[f.get(k, 0.0) for k in allnames] for f in X], float); ply = np.array([f['__ply'] for f in X])
    if mask is None:
        mask = np.ones(len(Z), bool)
    if mask.sum() < 40:
        return None
    dropped = []                                       # a feature that is only a clock (it just counts how many moves have been played) is not strategy
    keep = []
    for j, k in enumerate(allnames):
        c = np.corrcoef(M0[mask, j], ply[mask])[0, 1] if M0[mask, j].std() > 0 and ply[mask].std() > 0 else 0.0
        (dropped if abs(c) > 0.97 else keep).append(k if abs(c) > 0.97 else j)
    names = [allnames[j] for j in keep]; M = M0[:, keep]
    if not names:
        return None
    A, y = M[mask], Z[mask]; idx = rng.permutation(len(y)); cut = int(len(y) * 0.7) if hold else len(y); tr, te = idx[:cut], idx[cut:]
    mu, sd = A[tr].mean(0), A[tr].std(0) + 1e-9; Zs = (A - mu) / sd; bias = y[tr].mean()
    w = np.linalg.solve(Zs[tr].T @ Zs[tr] + ridge * np.eye(len(names)), Zs[tr].T @ (y[tr] - bias)); r2 = float('nan')
    if hold and len(te) > 10:
        pred = Zs[te] @ w + bias; r2 = 1 - ((y[te] - pred) ** 2).sum() / max(1e-9, ((y[te] - y[te].mean()) ** 2).sum())
    return dict(coef=dict(zip(names, w)), r2=float(r2), n=int(mask.sum()), names=names, w=w, mu=mu, sd=sd, bias=float(bias), dropped=dropped)


def strategy_agent(game, model, noise=0.0):
    """the discovered strategy as a player: look one move ahead and pick the move whose resulting position the fitted model likes best"""
    names, w, mu, sd, bias = model['names'], model['w'], model['mu'], model['sd'], model['bias']

    def agent(game_, s, rng):
        best, bs = None, -1e9
        for a in game_.legal(s):
            t = game_.step(s, a)
            if t.winner is not None:
                v = 1e6 if t.winner == s.turn else (0.0 if t.winner == 0 else -1e6)
            elif t.turn != s.turn and any(game_.step(t, b).winner == t.turn for b in game_.legal(t)):
                v = -1e5                                                  # never allow an immediate loss if there is a way not to (same safety net as 'greedy')
            else:
                f = game_.features(t); x = (np.array([f.get(k, 0.0) for k in names]) - mu) / sd; v = float(x @ w + bias) * (1 if t.turn == s.turn else -1)
            v += rng.random() * 1e-3 + (rng.standard_normal() * noise if noise else 0.0)
            if v > bs:
                bs, best = v, int(a)
        return best
    return agent


def strategy(game, rng, quick, log=print):
    ag, lo, hi = _agents(quick); n = 14 if quick else 40; gamelog.set_label('strategy data, round 1: weak search vs weak search'); X, Z, P = collect(game, ag['weak'], ag['weak'], n, rng)
    log('  strategy data: %d positions from %d games' % (len(Z), n))
    out = dict(all=fit_model(X, Z, P, rng), early=fit_model(X, Z, P, rng, P < 0.4), late=fit_model(X, Z, P, rng, P >= 0.6), positions=len(Z), games=n)
    out['n_rand'] = None
    # turn the finding into a player, test it, then let the player generate its own data and refit (a second round)
    m = n if quick else 30; rows = []
    if out['all']:
        full1 = fit_model(X, Z, P, rng, hold=False); a1 = strategy_agent(game, full1)
        for label, opp in (('vs random', ag['random']), ('vs greedy', ag['greedy']), ('vs weak search', ag['weak'])):
            gamelog.set_label('test of the discovered strategy (round 1) ' + label); r = B.play_match(game, a1, opp, m, rng, ('discovered strategy', label.replace('vs ', ''))); rows.append((label, r['score'], r['win'], r['draw'], r['loss'])); log('  discovered strategy %s: %.2f' % (label, r['score']))
        gamelog.set_label('strategy data, round 2: discovered strategy plays itself'); X2, Z2, P2 = collect(game, strategy_agent(game, full1, noise=0.15), strategy_agent(game, full1, noise=0.15), max(6, n // 2), rng)
        full2 = fit_model(X + X2, np.concatenate([Z, Z2]), np.concatenate([P, P2]), rng, hold=False); a2 = strategy_agent(game, full2)
        gamelog.set_label('test: round 2 strategy vs round 1 strategy'); r = B.play_match(game, a2, a1, m, rng, ('round 2 strategy', 'round 1 strategy')); rows.append(('round 2 strategy vs round 1 strategy', r['score'], r['win'], r['draw'], r['loss']))
        gamelog.set_label('test: round 2 strategy vs weak search'); r = B.play_match(game, a2, ag['weak'], m, rng, ('round 2 strategy', 'weak search')); rows.append(('round 2 strategy vs weak search', r['score'], r['win'], r['draw'], r['loss']))
        fit2 = fit_model(X + X2, np.concatenate([Z, Z2]), np.concatenate([P, P2]), rng)
        out.update(rows=rows, round1=full1['coef'], round2=full2['coef'], games_each=m, fit2=fit2, draw1=float(np.mean(Z == 0)), draw2=float(np.mean(Z2 == 0)))
    return out


def pct(x):
    return '%d%%' % round(100 * x)


def write_report(game, name, h, o, st, secs, quick, path):
    notes = getattr(game, 'feature_notes', {}); nice = lambda k: notes.get(k, k.replace('_', ' '))
    L = ['# Game Lab report: %s' % name, '', 'Made by `python run.py lab %s%s`. Nothing private is in it.' % (name, ' --quick' if quick else ''), '',
         '## 1. The rules as the program has them (please check these against the real game)', ''] + ['- ' + t for t in (game.describe() if hasattr(game, 'describe') else ['(this game gives no rule summary)'])]
    L += ['', 'Game family tag: **%s**. Board encoding: %d numbers, %d possible actions, %s symmetric views.' % (game.family, game.input_size(), game.n_actions, len(game.syms) if game.syms else 1), '',
          '## 2. Health check', '', '| Measure | Value | Based on | What it means |', '|---|---|---|---|']
    n = h['n']; lad = h['ladder']; sk = lad['strong search vs weak search'][0]; cap = game.max_ply if hasattr(game, 'max_ply') else None
    L.append('| Choices per turn (average) | %.1f | %d random games | more choices = harder to read ahead |' % (h['branching'], h['random_games']))
    L.append('| Game length, random players | %.0f moves | %d games | |' % (h['rand_len'], h['random_games']))
    L.append('| Game length, search players | %.0f moves | %d games | |' % (h['weak_len'], n))
    L.append('| Draws, random players / search players | %s / %s | | too many draws = boring or the limit is too tight |' % (pct(h['rand_draw']), pct(h['weak_draw'])))
    L.append('| First player wins, random players | %s | %d games | 50%% (minus draws) is fair |' % (pct(h['rand_p1']), h['random_games']))
    L.append('| First player score, search players | %.2f | %d games | 0.50 is fair; over 0.65 or under 0.35 is a real edge |' % (h['weak_p1'], n))
    L.append('| Tactics: positions with a win in one move | %s | random games | high = sharp and tactical, low = quiet and strategic |' % pct(h['tactics']))
    L += ['', '**Skill ladder** (score = wins + half the draws, 0.50 = level; each row is %d games; "weak search" thinks %d tries per move, "strong" %d; unfinished play-outs are scored by piece count):' % (n, h['lo'], h['hi']), '',
          '| Match | Score | W / D / L |', '|---|---|---|'] + ['| %s | %.2f | %d / %d / %d |' % (k, v[0], v[1], v[2], v[3]) for k, v in lad.items()]
    L += ['', '*How it ended in random games:* ' + ', '.join('%s %d' % kv for kv in sorted(h['rand_why'].items(), key=lambda kv: -kv[1])) + '. *In search games:* ' + ', '.join('%s %d' % kv for kv in sorted(h['weak_why'].items(), key=lambda kv: -kv[1])) + '.']
    L += ['', '## 3. Openings', '', 'By symmetry there are only **%d different first moves** out of %d (others are the same move turned or mirrored).' % (o['kinds'], o['total']), '',
          'First-player score after each kind of opening (%d games each, both sides played by the weak search; noisy):' % o['games_each'], '', '| Opening (action number) | Moves it stands for | First-player score |', '|---|---|---|'] + ['| %d | %d | %.2f |' % r for r in o['table'][:8]]
    L += ['', '## 4. What predicts winning (a plain linear fit, not a deep model)', '']
    if st['all']:
        for key, title in (('all', 'Whole game'), ('early', 'First 40% of the game'), ('late', 'Last 40% of the game')):
            fit = st[key]
            if not fit:
                continue
            ranked = sorted(fit['coef'].items(), key=lambda kv: -abs(kv[1]))[:6]
            L += ['**%s** (%d positions; the fit explains %.0f%% of the outcome variation on positions it had not seen):' % (title, fit['n'], 100 * max(0, fit['r2'])), '']
            L += ['- %s: **%s** (strength %.2f)' % (nice(k), 'helps you the more of it you have' if v > 0 else 'hurts you the more of it you have', abs(v)) for k, v in ranked] + ['']
        dr = st['all'].get('dropped') or []
        if dr:
            L += ['*Left out as "clock" features* (they only count how many moves have been played, which is not strategy): ' + ', '.join(nice(k) for k in dr) + '.', '']
        L += ['*Reading this:* strength is a standardised effect (about how far one typical step of that feature moves the result on a scale of -1 to +1). Features that move together (for example your pieces and the opponent\'s) can share or swap credit, so read the order, not the exact numbers.']
    else:
        L += ['Not enough positions to fit a model.']
    if st.get('rows'):
        L += ['', '## 4b. Does the discovered strategy actually win?', '', 'The program turned the fit above into a player (take a win if there is one, never allow an immediate loss if it can help it, otherwise pick the move that leaves the position the fit likes best), then tested it (%d games per row; score = wins + half the draws):' % st['games_each'], '',
              '| Match | Score | W / D / L |', '|---|---|---|'] + ['| %s | %.2f | %d / %d / %d |' % r for r in st['rows']]
        top = sorted(st['round1'], key=lambda k: -abs(st['round1'][k]))[:5]
        L += ['', 'Round 2 = the same player generated its own games and the fit was repeated. Do the main factors stay put? (strength round 1 -> round 2)', ''] + ['- %s: %+.2f -> %+.2f' % (nice(k), st['round1'][k], st['round2'].get(k, 0.0)) for k in top]
    if st.get('fit2'):
        f2 = st['fit2']; ranked = sorted(f2['coef'].items(), key=lambda kv: -abs(kv[1]))[:6]
        L += ['', '## 4c. Findings after round 2', '', 'Round 1 data came from the weak search players (%s of their positions ended in a draw); round 2 added games played by the discovered strategy itself (%s drawn). When round 1 is mostly draws it has little to learn from, and round 2 is the better guide. Fit on both (%d positions, explains %.0f%% on unseen positions):' % (pct(st['draw1']), pct(st['draw2']), f2['n'], 100 * max(0, f2['r2'])), '']
        L += ['- %s: **%s** (strength %.2f)' % (nice(k), 'helps you the more of it you have' if v > 0 else 'hurts you the more of it you have', abs(v)) for k, v in ranked]
    folk = FOLK.get(game.family, [])
    if folk and st['all']:
        L += ['', '## 5. Does the usual advice agree with the data?', '', 'Advice people give for games of the "%s" family, checked against the fit above (whole game):' % game.family, '', '| Advice | Feature | Data says | Verdict |', '|---|---|---|---|']
        for text, feat, sign in folk:
            c = st['all']['coef'].get(feat)
            if c is None:
                L.append('| %s | %s | (not measured for this game) | - |' % (text, feat)); continue
            ok = c * sign > 0.03; bad = c * sign < -0.03
            L.append('| %s | %s | %+.2f | %s |' % (text, nice(feat), c, 'agrees' if ok else 'disagrees' if bad else 'no clear effect'))
    L += ['', '## %d. Suggestions (written by rules in the program, so treat them as prompts to think, not as facts)' % (6 if folk else 5), '']
    sug = []
    if h['weak_draw'] > 0.3: sug.append('Many drawn games between search players (%s). If that bores you, shorten the game, raise the reward for attacking, or loosen a limit.' % pct(h['weak_draw']))
    if cap and h['weak_why'].get('limit', 0) / n > 0.3: sug.append('A third or more of search games stopped at the move limit (%d). Either raise the limit or add a rule that pushes players to commit.' % cap)
    if abs(h['weak_p1'] - 0.5) > 0.15: sug.append('The first player seems %s (score %.2f over %d games). That is a small sample: repeat with another --seed before changing rules. A fix could be a small bonus for the second player.' % ('ahead' if h['weak_p1'] > 0.5 else 'behind', h['weak_p1'], n))
    if sk < 0.6: sug.append('The strong search did not clearly beat the weak one (%.2f). Either luck decides this game, play-outs are a poor guide here (for example most end by the move limit), or thinking a bit deeper does not help yet. Do not read this as proof that skill is irrelevant.' % sk)
    elif sk > 0.8: sug.append('Thinking ahead pays off a lot (%.2f). That is a sign of a game rich in skill.' % sk)
    if lad['greedy vs random'][0] < 0.6: sug.append('A greedy "take a win, avoid a loss" player does not beat random (%.2f). Short tactics do not decide this game: plans and structure do (or most games end at the move limit).' % lad['greedy vs random'][0])
    if h['tactics'] > 0.35: sug.append('Winning moves are on offer in %s of random positions: a sharp, tactical game where missing a threat costs the game.' % pct(h['tactics']))
    if o['kinds'] <= 3: sug.append('Only %d genuinely different first moves exist, so the opening is not where the game is decided.' % o['kinds'])
    if st.get('rows'):
        R = st['rows']; best = max(R[0][1], R[1][1], R[2][1], R[4][1])
        if best <= 0.55: sug.append('The discovered one-move-ahead strategy does not beat random, greedy or the weak search in either round (best score %.2f). The features the game lists do not capture how it is won, or games are decided by the move limit. Adding better features to `features()` is the next step.' % best)
        else:
            sug.append('The discovered strategy reached %.2f against the best opponent it met, using only the features listed in this report, so those features carry real winning information.' % best)
            if R[3][1] > 0.65: sug.append('Round 2 beat round 1 (%.2f): playing its own games and refitting improved the strategy. Running more rounds would probably help; the first fit was learning from mostly drawn games.' % R[3][1])
    if not sug: sug.append('Nothing stood out. The game looks balanced on these measures. Run without --quick for steadier numbers.')
    L += ['- ' + t for t in sug]
    L += ['', '## Honest limits', '', '- Strategy findings come from **weak search players** (%d tries per move), so they describe how this game is won at that level, not how experts win. Run without `--quick` for more games.' % h['lo'],
          '- The fit sees only the features the game lists (see `features()` in games.py). A strategy that needs a feature nobody listed will not appear.',
          '- Every table says how many games it rests on. With 8 to 40 games, gaps under 0.15 are noise.', '- Time taken: %.1f minutes.' % (secs / 60)]
    open(path, 'w').write('\n'.join(L) + '\n')


def run(name, quick=False, seed=0, out_dir='results', variants=None):
    rng = np.random.default_rng(seed); os.makedirs(out_dir, exist_ok=True)
    if variants:
        return run_variants(name, variants, quick, seed, out_dir)
    game = make_game(name); t0 = time.time(); print('Game Lab: %s (%s)' % (name, 'quick' if quick else 'full'))
    gamelog.open_log(os.path.join(out_dir, 'lab_%s_games.jsonl' % name), name)
    print('1/3 health check'); h = health(game, rng, quick); print('2/3 openings'); o = openings(game, rng, quick); print('3/3 what predicts winning'); st = strategy(game, rng, quick)
    gamelog.close_log()
    path = os.path.join(out_dir, 'lab_%s.md' % name); write_report(game, name, h, o, st, time.time() - t0, quick, path); print('\nDone. The report is in', path)
    print('Every game was saved. Watch one with:  python run.py replay %s 12   (any number; python run.py replay %s --list shows them all)' % (name, name)); return path


def parse_variants(text):
    """'pieces=6,9 flying=on,off' -> list of dicts, every combination"""
    keys, vals = [], []
    for part in text.split():
        k, v = part.split('='); keys.append(k); vals.append([{'on': True, 'off': False, 'true': True, 'false': False}.get(x.lower(), None) if x.lower() in ('on', 'off', 'true', 'false') else int(x) for x in v.split(',')])
    return [dict(zip(keys, combo)) for combo in itertools.product(*vals)]


def run_variants(name, text, quick, seed, out_dir):
    rng = np.random.default_rng(seed); t0 = time.time(); rows = []
    for kw in parse_variants(text):
        game = make_game(name, **kw); print('variant', kw); h = health(game, rng, True if quick else False, log=lambda m: None); lad = h['ladder']
        rows.append((kw, h, lad['strong search vs weak search'][0], lad['greedy vs random'][0]))
    L = ['# Game Lab variants: %s' % name, '', 'Same measures for each rule variant. Every cell rests on %d search games (%d random games for the random columns); gaps under 0.15 are noise.' % (rows[0][1]['n'], rows[0][1]['random_games']), '',
         '| Variant | Choices/turn | Length (search) | Draws (search) | First-player score | Skill gap (strong vs weak) | Greedy vs random | Health flags |', '|---|---|---|---|---|---|---|---|']
    for kw, h, sk, gr in rows:
        flags = []
        flags.append('draws ok' if h['weak_draw'] <= 0.3 else 'too many draws'); flags.append('fair start' if abs(h['weak_p1'] - 0.5) <= 0.15 else 'start edge'); flags.append('skill pays' if sk >= 0.65 else 'skill gap small')
        L.append('| %s | %.1f | %.0f | %s | %.2f | %.2f | %.2f | %s |' % (', '.join('%s=%s' % kv for kv in kw.items()), h['branching'], h['weak_len'], pct(h['weak_draw']), h['weak_p1'], sk, gr, '; '.join(flags)))
    L += ['', 'Time: %.1f minutes. Pick the variant with the most good flags, then run the full lab on it.' % ((time.time() - t0) / 60)]
    path = os.path.join(out_dir, 'lab_%s_variants.md' % name); open(path, 'w').write('\n'.join(L) + '\n'); print('\n'.join(L)); print('\nDone. The report is in', path); return path
