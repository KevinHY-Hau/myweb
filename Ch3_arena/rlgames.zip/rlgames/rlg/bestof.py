"""BEST OF FIVE: train five variants of the learner, score them all in the same fair way, keep the best, then merge all five into ONE student model.
    python run.py best_of tictactoe              # about 5 times the length of one `train`
The merge is called DISTILLATION: the five models act together as a "teacher committee" (their answers are averaged, the better models count more),
and one student network is trained to give the committee's answer on its own. The student starts as a copy of the best single model.
Nothing here is new science: ensembles and distillation are old ideas. What is new is only the small, readable version for these games.
Honest rule: the student is only chosen if it scores at least as well as the best single model on the same check. Gaps under about 0.15 are noise."""
import os, json, time
import numpy as np
from . import train as T, baselines as B, gamelog
from .games import make_game
from .net import Net
from .mcts import search, pick
from .experiments import VARIANTS


def score_net(game, name, net, cfg, n, rng):
    """the same fair check for every model: wins + half draws, out of 1, against opponents that never change"""
    ag = B.net_mcts_agent(net, cfg['eval_sims']); r = {}
    r['vs_random'] = B.play_match(game, ag, B.random_agent, n, rng)['score']; r['vs_greedy'] = B.play_match(game, ag, B.greedy_agent, n, rng)['score']
    r['vs_rollout'] = B.play_match(game, ag, B.rollout_mcts_agent(cfg['rollout']), max(4, n // 2), rng)['score']
    parts = [r['vs_random'], r['vs_greedy'], r['vs_rollout']]
    if name == 'tictactoe':
        m = B.play_match(game, ag, B.perfect_ttt_agent(), n, rng); r['vs_perfect'] = m['score']; r['lost_to_perfect'] = m['loss']; parts.append(m['score'])
    r['avg'] = float(np.mean(parts)); return r


def committee(game, nets, weights):
    """an evaluator (see mcts.py) that asks every model and averages the answers; the better a model scored, the more its answer counts"""
    w = np.array(weights, float); w = w / w.sum()

    def f(g, s):
        legal = g.legal(s); x = g.encode(s); P = np.zeros(len(legal)); v = 0.0
        for wk, net in zip(w, nets):
            logits, val = net.predict(x); l = logits[legal]; e = np.exp(l - l.max()); P += wk * e / e.sum(); v += wk * val
        return P, v
    return f


def positions_from_games(game, paths, limit, rng):
    """every different position that appears in the games the five runs recorded (so the student studies places the models actually reached)"""
    seen = {}; 
    for path in paths:
        if not os.path.exists(path):
            continue
        for line in open(path):
            d = json.loads(line)
            if d.get('header'):
                continue
            s = game.initial(); z = 0 if d['winner'] == 0 else d['winner']
            for a in d['actions']:
                if game.result(s) is not None:
                    break
                key = game.encode(s).tobytes()
                if key not in seen:
                    seen[key] = (s, 0.0 if d['winner'] == 0 else (1.0 if d['winner'] == s.turn else -1.0))
                s = game.step(s, int(a))
    items = list(seen.values()); idx = rng.permutation(len(items))[:limit]
    return [items[i] for i in idx], len(items)


def distil(game, name, cfg, nets, weights, student, paths, rng, positions, sims, steps, quiet=False):
    pos, total = positions_from_games(game, paths, positions, rng); ev = committee(game, nets, weights); X = []; PI = []; Z = []
    for k, (s, z_game) in enumerate(pos):
        legal, visits = search(game, s, ev, sims, rng, noise=0.0)
        if len(legal) == 0:
            continue
        pi = np.zeros(game.n_actions, np.float32); pi[legal] = visits / visits.sum(); _, vt = ev(game, s)
        X.append(game.encode(s)); PI.append(pi); Z.append(0.5 * vt + 0.5 * z_game)           # value target: half the committee's opinion, half what really happened
        if not quiet and k % 500 == 0:
            print('  asking the committee: %d of %d positions' % (k, len(pos)), flush=True)
    X = np.stack(X); PI = np.stack(PI); Z = np.array(Z, np.float32); student.lr = 3e-4; lp = lv = 0.0
    for _ in range(steps):
        idx = rng.integers(len(X), size=cfg['batch']); xb = []; pb = []
        for i in idx:
            x, p = X[i], PI[i]
            if game.syms:
                xp, pp = game.syms[rng.integers(len(game.syms))]; x, p = x[xp], p[pp]
            xb.append(x); pb.append(p)
        lp, lv = student.train_step(np.stack(xb), np.stack(pb), Z[idx])
    return dict(positions_used=len(X), positions_seen=total, loss_policy=round(lp, 3), loss_value=round(lv, 3))


def run(name, minutes, iters, seed, out_dir, eval_games=None, positions=3000, sims=40, steps=400, quiet=False):
    t0 = time.time(); game = make_game(name); cfg = T.CONFIGS.get(name) or T.DEFAULT_CONFIG; n = eval_games or max(30, cfg['eval_games'] * 2)
    folder = os.path.join(out_dir, name + '_bestof'); os.makedirs(folder, exist_ok=True); names = list(VARIANTS); nets = []; paths = []; rows = []
    for k, v in enumerate(names):
        sw, desc = VARIANTS[v]; print('\n=== variant %d of %d: %s  (%s)' % (k + 1, len(names), v, desc), flush=True)
        f, _ = T.train(name, minutes, iters, seed + 10 * k, folder, switches=sw, tag=v, quiet=quiet)
        nets.append(Net.load(os.path.join(f, 'model.npz'))); paths.append(os.path.join(f, 'games.jsonl'))
    print('\n=== scoring all five the same way (%d games per opponent)' % n, flush=True); rng = np.random.default_rng(seed + 999)
    for v, net in zip(names, nets):
        r = score_net(game, name, net, cfg, n, rng); r['variant'] = v; rows.append(r); print('  %-15s average %.2f' % (v, r['avg']), flush=True)
    bi = int(np.argmax([r['avg'] for r in rows])); best = nets[bi]; best.save(os.path.join(folder, 'model_best_single.npz'))
    print('\n=== merging the five into one student (starts as a copy of the best, "%s")' % names[bi], flush=True)
    student = best.copy(); info = distil(game, name, cfg, nets, [max(0.05, r['avg']) ** 2 for r in rows], student, paths, np.random.default_rng(seed + 5), positions, sims, steps, quiet)
    student.save(os.path.join(folder, 'model_student.npz')); print('=== checking the student against the best single model', flush=True)
    rng = np.random.default_rng(seed + 999); sr = score_net(game, name, student, cfg, n, rng); sr['variant'] = 'student (all five merged)'
    h2h = B.play_match(game, B.net_mcts_agent(student, cfg['eval_sims']), B.net_mcts_agent(best, cfg['eval_sims']), n, np.random.default_rng(seed + 31))
    chosen = 'student' if sr['avg'] >= rows[bi]['avg'] else 'best single'; (student if chosen == 'student' else best).save(os.path.join(folder, 'model.npz'))
    with open(os.path.join(folder, 'games_pooled.jsonl'), 'w') as out:
        out.write(json.dumps({'header': True, 'game': name}) + '\n'); k = 0
        for p in paths:
            if os.path.exists(p):
                for line in open(p):
                    d = json.loads(line)
                    if not d.get('header'):
                        k += 1; d['n'] = k; out.write(json.dumps(d) + '\n')
    write_report(name, folder, cfg, n, names, rows, bi, sr, h2h, chosen, info, time.time() - t0)
    print('\nDone. Files are in', folder); return folder


def write_report(name, folder, cfg, n, names, rows, bi, sr, h2h, chosen, info, secs):
    ttt = name == 'tictactoe'; hdr = '| model | vs random | vs greedy | vs rollout | ' + ('vs perfect | ' if ttt else '') + 'average |'
    def line(r, mark=''):
        return '| %s%s | %.2f | %.2f | %.2f | %s%.2f |' % (r['variant'], mark, r['vs_random'], r['vs_greedy'], r['vs_rollout'], ('%.2f | ' % r['vs_perfect']) if ttt else '', r['avg'])
    L = ['# Best of five: %s' % name, '', '- Five variants were trained (the experiment switches in `rlg/experiments.py`), scored the same way, the best one kept, then all five merged into one student model.',
         '- Time: %.1f minutes. Each score rests on %d games per opponent (rollout: half as many); a gap under about 0.15 is noise.' % (secs / 60, n), '',
         hdr, '|---|---|---|---|' + ('---|' if ttt else '') + '---|']
    for i, r in enumerate(rows):
        L.append(line(r, ' (best single)' if i == bi else ''))
    L.append(line(sr)); gap = sr['avg'] - rows[bi]['avg']
    L += ['', '## Merging (distillation)', '', '- The five models answered together as a committee (better models count more) on %d different positions taken from the games of the five runs (%d different positions existed).' % (info['positions_used'], info['positions_seen']),
          '- The student was trained to give the committee\'s answer on its own. Final training loss: policy %.3f, value %.3f.' % (info['loss_policy'], info['loss_value']), '',
          '## Reading (written by the program, not by a person)', '',
          '- Student vs best single model, head to head: %d wins, %d draws, %d losses (score %.2f; 0.50 = level).' % (h2h['win'], h2h['draw'], h2h['loss'], h2h['score']),
          '- Average score: student %.2f, best single %.2f (gap %+.2f).' % (sr['avg'], rows[bi]['avg'], gap),
          '- `model.npz` is the **%s**.' % chosen + (' A gap this small is within noise: treat the two as level.' if abs(gap) < 0.15 else ''),
          '- Files: `model.npz` (the chosen one), `model_student.npz`, `model_best_single.npz`, `games_pooled.jsonl` (all games of the five runs, ready for the Learn tab).']
    open(os.path.join(folder, 'report.md'), 'w').write('\n'.join(L) + '\n')
