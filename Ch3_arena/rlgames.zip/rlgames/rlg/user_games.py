"""YOUR GAMES GO HERE. Every game you add is available to every command:  python run.py lab <name>   train <name>   selftest ...

To add a game, copy the Nim class below and change it. You must provide (see rlg/games.py for four finished examples):
    initial()    the starting State
    legal(s)     array of legal action numbers (empty when the game is over)
    step(s, a)   a NEW State after action a (never change s). Set t.winner = colour of the winner (1 or -1), or 0 for a draw, when the game ends.
    encode(s)    the board as a list of numbers, seen from the player to move (so the same network can play both sides)
    plus the sizes: n_actions, planes, H, W   (encode() must return planes*H*W numbers)
Optional but very useful for the Lab:
    features(s)  named numbers that might matter for winning ({'my_pieces': 5, 'centre': 2, ...}). THE LAB CAN ONLY DISCOVER STRATEGIES THAT USE
                 FEATURES YOU GIVE IT. Add the ideas you suspect; the Lab tells you which ones matter.
    describe()   the rules in plain words (the Lab prints them so you can check the program has the game right)
    syms         the turns/mirrors of the board that leave the game unchanged (see Flock and Morris)
    family       a word for the kind of game, used to look up common advice ('connect', 'surround', 'capture + reach', 'mill / placement')
Then add the game's name to USER_GAMES at the bottom.

Colours: 1 = player who moves first, -1 = second. A State needs  b (numpy array), turn, ply, winner (None while playing), extra, why.
"""
import numpy as np
from .games import Game, State


class Nim(Game):
    """Three piles of stones. On your turn take one or more stones from ONE pile. Whoever takes the LAST stone wins.
    This game is solved: a position is lost for the player to move exactly when the XOR (nim-sum) of the pile sizes is 0.
    It is here as a teaching example, and as a test of the Lab: give the Lab the feature that holds the secret, and it finds the strategy;
    leave the feature out (set SECRET = False) and it finds nothing. The Lab only ever discovers strategies written in the features it is given."""
    name = 'nim'; H, W, planes = 1, 3, 1; family = 'take-away'
    SECRET = True                   # False: do not give the Lab the nim-sum idea
    MAXP = 7
    feature_notes = {'nim_sum_is_zero': 'the pile sizes XOR to zero (the known losing pattern for the player to move)', 'stones': 'stones left', 'biggest_pile': 'size of the biggest pile',
                     'piles_left': 'piles not yet empty'}

    def __init__(self, piles=(3, 4, 5)):
        self.piles = tuple(piles); self.n_actions = 3 * self.MAXP
        import itertools
        self.sq_perms = [np.array(p) for p in itertools.permutations(range(3))]            # the three piles can be swapped freely: 6 views
        self.syms = [(p, np.array([p[i] * self.MAXP + k for i in range(3) for k in range(self.MAXP)])) for p in self.sq_perms]

    def describe(self):
        return ['Three piles of stones: %s.' % ', '.join(map(str, self.piles)), 'On your turn take 1 or more stones from ONE pile.', 'Whoever takes the last stone wins.']

    def initial(self):
        return State(np.array(self.piles, np.int8))

    def render(self, s):                 # optional, but needed to watch games with `python run.py replay`. Return text.
        return '\n'.join('pile %d: %s %d' % (i + 1, 'o' * int(n), int(n)) for i, n in enumerate(s.b))

    def action_text(self, a):           # optional: how a move is written in a replay
        i, k = divmod(int(a), self.MAXP); return 'take %d from pile %d' % (k + 1, i + 1)

    def legal(self, s):
        if s.winner is not None:
            return np.array([], int)
        return np.array([i * self.MAXP + k for i in range(3) for k in range(int(s.b[i]))], int)

    def step(self, s, a):
        t = s.copy(); i, k = divmod(int(a), self.MAXP); t.b[i] -= k + 1; t.ply += 1
        if not t.b.any():
            t.winner = s.turn; t.why = 'last stone'
        t.turn = -s.turn
        return t

    def encode(self, s):
        return (s.b / float(self.MAXP)).astype(np.float32)

    def features(self, s):
        f = {'stones': int(s.b.sum()), 'biggest_pile': int(s.b.max()), 'piles_left': int((s.b > 0).sum())}
        if self.SECRET:
            f['nim_sum_is_zero'] = float(int(s.b[0]) ^ int(s.b[1]) ^ int(s.b[2]) == 0)
        return f

    def transform(self, s, k):
        t = s.copy(); t.b = s.b[self.sq_perms[k]].copy(); t._legal = None; return t


USER_GAMES = {'nim': Nim, 'nim_blind': lambda: _blind()}


def _blind():
    g = Nim(); g.SECRET = False; g.name = 'nim_blind'; return g
