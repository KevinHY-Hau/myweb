# Game Learner: one reinforcement-learning program for many board games

You run it on your own computer. It plays itself, learns, and writes a short report.
Needs only **Python 3.9+ and NumPy** (`pip install numpy`). No GPU, no PyTorch, nothing uploaded anywhere.

## Run it (smallest game first)

```
python run.py selftest                 # 10 seconds. Everything should say ok / ALL GOOD
python run.py list                     # the games
python run.py train tictactoe          # about 2 to 3 minutes
python run.py train connect4mini       # about 5-10 minutes
python run.py train connect4 --minutes 20
python run.py train othello6 --minutes 30
python run.py train flock5 --minutes 45     # a full default run is nearer an hour
python run.py experiments tictactoe    # the strategy-book experiments (see the wiki page)
python run.py lab morris --quick       # the Game Lab (see the section further down)
python run.py play tictactoe results/tictactoe/model.npz     # play the thing you trained
```
`--minutes N` stops after N minutes and still writes the report. `--seed 1` changes the randomness (run 2 or 3 seeds before trusting a small difference).

## What to send back
After each run, the program prints the path of a file such as `results/connect4/report.md`. Paste that file to me.
For `experiments` it is `results/experiments_<game>.md`. If something fails, paste the last 20 lines of the screen.

## What the numbers mean
- **vs random / greedy / rollout:** the learner (with a little search) against opponents that never change. Score = wins + half of draws, 0 to 1, 0.50 = level.
  *random* plays any legal move. *greedy* takes an immediate win and avoids an immediate loss. *rollout* is a plain tree search that judges positions by random play-outs (no learning at all).
- **instinct vs random:** the network alone, no search. This is the cleanest sign that it has really learned. Early scores in the other columns are high partly because the **search** is already strong; watch whether *instinct* and *vs rollout* climb.
- **vs previous:** the learner against its own earlier copy. Above 0.5 = still improving.
- **vs perfect (tic-tac-toe only):** against a player that never errs. 0.50 means it always drew, which is the best possible. A lower number means it lost some games.
- **opening variety:** 1 = tries many first moves in self-play, 0 = always the same one.
- Each cell is only 10 to 40 games: gaps under about 0.15 are noise.

## The files
- `rlg/games.py` the four games behind one interface (Game), including each game's rotations and mirrors (`syms`). Add a game here and every other file works with it.
- `rlg/net.py` a small neural network with a move head and a win head, backpropagation written by hand in NumPy.
- `rlg/mcts.py` the tree search (PUCT) that turns the network's guesses into better moves.
- `rlg/train.py` the loop: self-play, learn, measure. All settings per game are in `CONFIGS` at the top.
- `rlg/baselines.py` the fixed opponents and the match runner.
- `rlg/experiments.py` switch one ingredient off at a time and compare.
- `rlg/lab.py` the Game Lab. `rlg/user_games.py` where your own games go (Nim is the worked example).
- `rlg/selftest.py` quick checks of the rules and the learner.
- `run.py` the command line.

## Game Lab: measure a game and find how to win it
```
python run.py lab morris --quick                           # about 1 minute: a first look
python run.py lab morris                                   # about 10 minutes: steadier numbers
python run.py lab morris --variants "pieces=6,9 flying=on,off"   # compare rule variants side by side
python run.py lab nim                                      # a solved game, to see the Lab find a strategy
```
It writes `results/lab_<game>.md`. Paste that file to me. The report has: the rules as the program has them (**check these**), a health check (length, draws, first-player edge, skill versus luck, tactics), the different openings, what predicts winning, whether the discovered strategy really wins when turned into a player, whether the usual advice for that kind of game agrees with the data, and suggestions.

**Adding a game:** copy the `Nim` class in `rlg/user_games.py`, change it, add its name at the bottom. The file explains each part. Or tell me the rules and I write the class. The Lab can only discover strategies written in the *features* you give it (`features()` in the class); try `nim` against `nim_blind` to see why.

## The Game Arena web page, and learning from games

The Game Arena (kit project `arena`, a work page) runs THIS package inside the browser (Pyodide). You choose a `model.npz` and a `games.jsonl` (both written by `python run.py train`), then you can watch the games (up to 16 boards), play against the model, let it learn from the games, and download the updated model, games and a report. Nothing is uploaded anywhere.

The same learner runs on your computer:

```
python run.py learn tictactoe --model results/tictactoe/model.npz --games results/tictactoe/games.jsonl --rounds 3 --selfplay 6
```

It writes `model_updated.npz`, `games_updated.jsonl` and `report.md` to `results/learned`. How it learns (see `rlg/web_api.py`): the value target is who won; the move target copies the winner's move (40% weight, the rest is what the network already thought), half as strongly for a draw, not at all for a loser; moves of the `random` and `greedy` fixed players are never copied; then some self-play is added and the network trains on the mix. Before and after, the model plays fixed opponents and the model you gave it. Measured: a Connect 4 model improved against its original (about 0.7 to 0.9 over 36 games) when learning from a large file of its own later games; a tiny Connect 4 mini run did not improve. Read the report's before/after table and keep the old model if it is not clearly better.

## Using all your CPU cores (faster training)

`train` and `experiments` play the self-play games and the check matches on several CPU cores at once. The default is automatic (half of your logical CPUs, at most 8). Games are independent, so this is almost a straight multiple.

```
python run.py train morris                 # automatic
python run.py train morris --workers 4     # choose
python run.py train morris --workers 1     # off (the old way, one core)
```

The training maths itself still runs on one core. A GPU is not used: with a network this small and one position per question, the data copying costs more than the GPU saves. If the PC gets hot or other programs lag, use a smaller --workers. The Lab (`lab`) does not use workers yet.

## Watch any game it played (replay)

Every game from `train` and `lab` is saved with a number (training self-play, the check matches, the Lab's skill ladder and strategy tests).

```
python run.py replay morris --list            # all games: number, what it was, result, length
python run.py replay morris 100               # game 100 move by move (Enter = next move, Ctrl-C = stop)
python run.py replay morris 100 --all         # the whole game at once
python run.py replay morris 100 --source lab  # if both a training run and a lab run exist (default: training first)
python run.py train connect4 --keep-every 5   # a long run saves a lot: keep only every 5th game
```

Files: `results/<game>/games.jsonl` (training) and `results/lab_<game>_games.jsonl` (lab). Only the move list is stored, and replay re-plays it through the rules, so it warns if the rules changed since. Your own games: give the class an optional `render(s)` and `action_text(a)` (see Nim) or the replay shows raw numbers. Lab rule-variant sweeps (`--variants`) do not save games.

## Symmetry (rotations and mirrors)
- Tic-tac-toe, Othello and Flock look the same after turning the board by 90 degrees or mirroring it: 8 views. Connect 4 only has the left-right mirror (gravity).
- The learner uses this automatically: every training position is shown through a random turn or mirror. `python run.py experiments <game> --which baseline,no_augment` measures what it is worth.
- `--tta` (with `eval` or `play`) averages the network over every view when it thinks. Slower, steadier.
- To give a new game symmetry, fill in `syms` in its class. `python run.py selftest` then checks it by playing.

## Honest limits
- It learns the **small** games. Full chess, shogi or Go need far more computing than a laptop.
- Games with dice (Runes, backgammon) and hidden information are not included yet. The search needs a "chance" step for them.
- It is a teaching-size AlphaZero: small network, few simulations. It will not beat a good hand-written engine on Connect 4 or Othello, but it learns without any game knowledge except the rules.
- Timings are rough, measured on a 2-core cloud machine; your computer may be faster or slower.


### About
  Kevin Hon Yin Hau (All done by Claude) - Oct 2026
  https://kevinhyhau.co.uk/Ch3_arena/

## Best of five (merge several runs into one model)

```
python run.py best_of tictactoe              # about five times as long as one `train`
python run.py best_of connect4 --minutes 5   # --minutes is per variant
```

It trains the five variants from `experiments` (full recipe, no root noise, no temperature, few searches, no symmetry views), scores all five the same way, keeps the best, and then **merges all five into one student model** (distillation): the five models answer together as a committee (better models count more) on positions taken from their own games, and a student network, starting as a copy of the best one, is trained to give the committee's answer by itself.

It writes to `results/<game>_bestof/`: `model.npz` (the chosen one), `model_student.npz`, `model_best_single.npz`, `games_pooled.jsonl` (all games of the five runs, ready for the Learn tab) and `report.md`. The student is only chosen if it scores at least as well as the best single model; gaps under about 0.15 are noise. The idea is old (ensembles, distillation, keep-the-winner); this is only a small readable version. A quick test on tic-tac-toe (20 iterations per variant, 20 games per check) did **not** show the student beating the best single model: they were level within noise.
